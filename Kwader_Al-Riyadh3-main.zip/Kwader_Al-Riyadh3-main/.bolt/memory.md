# Project memory

## Product intent & audience

- E-commerce storefront with an admin management panel.
- Storefront is public (no customer sign-in).
- Admin manages products, prices, stock, promo codes, and site text via an admin panel.

## Brand personality & voice

- Not yet inferred from content; awaiting copy or branding decisions.

## Visual design & UX direction

- Dark and light themes supported.
- Drawer components used in the UI.
- Tailwind CSS for styling; Lucide React for icons.
- `@/` path alias maps to `src/` for imports.
- Design goal: production-grade, non-cookie-cutter aesthetics.

## Decisions, constraints & rationale

- Backend: Supabase (database + schema + order-status function).
- Admin access currently gated by a simple PIN (1234) — hides the screen only, does not protect data.
- Vite build does not type-check; TypeScript check run separately.
- Build and type checks pass; Supabase security advisor identified unsecured writes as the key remaining gap.
- Admin data writes (products, prices, stock, promo codes, site text) are currently unprotected because the public Supabase key is embedded in client code.

## Open questions & assumptions

- Add real email-and-password admin sign-in and lock writes to it? (Recommended before launch; not yet implemented.)
- Layout, theme switching, and drawers are unverified in-browser — no runtime visual testing done yet.
- No customer accounts or checkout auth assumed; order-status lookup is public.