import { useState } from 'react';
import { CartProvider } from '@/context/CartContext';
import { CatalogProvider, useCatalog } from '@/context/CatalogContext';
import { NavigationProvider, useNavigation } from '@/context/NavigationContext';
import { PreferencesProvider } from '@/context/PreferencesContext';
import AnnouncementBar from '@/components/layout/AnnouncementBar';
import CartDrawer from '@/components/cart/CartDrawer';
import Footer from '@/components/layout/Footer';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import HomePage from '@/pages/HomePage';
import CatalogPage from '@/pages/CatalogPage';
import ProductPage from '@/pages/ProductPage';
import AboutPage from '@/pages/AboutPage';
import ServicesPage from '@/pages/ServicesPage';
import FlavorsPage from '@/pages/FlavorsPage';
import GalleryPage from '@/pages/GalleryPage';
import ContactPage from '@/pages/ContactPage';
import OffersPage from '@/pages/OffersPage';
import AdminPage from '@/pages/AdminPage';
import { usePreferences } from '@/context/PreferencesContext';

function resolvePage(path: string) {
  const productMatch = path.match(/^\/product\/([^/]+)$/);
  if (productMatch) return <ProductPage productId={decodeURIComponent(productMatch[1])} />;

  switch (path) {
    case '/':
      return <HomePage />;
    case '/catalog':
      return <CatalogPage />;
    case '/about':
      return <AboutPage />;
    case '/services':
      return <ServicesPage />;
    case '/flavors':
      return <FlavorsPage />;
    case '/gallery':
      return <GalleryPage />;
    case '/contact':
      return <ContactPage />;
    case '/offers':
      return <OffersPage />;
    default:
      return <HomePage />;
  }
}

function StoreShell() {
  const { path } = useNavigation();
  const { status, error, reload } = useCatalog();
  const { tx } = usePreferences();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (path === '/admin') return <AdminPage />;

  return (
    <div className="flex min-h-screen flex-col bg-bg text-ink">
      <AnnouncementBar />
      <Header onOpenSidebar={() => setSidebarOpen(true)} />
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <CartDrawer />
      <main className="flex-1">
        {status === 'loading' && (
          <div className="flex min-h-[60vh] items-center justify-center">
            <div className="h-10 w-10 animate-spin rounded-full border-2 border-line border-t-gold" />
          </div>
        )}
        {status === 'error' && (
          <div className="mx-auto flex max-w-md flex-col items-center gap-4 px-6 py-24 text-center">
            <p className="text-lg font-bold">
              {tx('تعذر تحميل المنتجات حالياً', 'We could not load the products right now')}
            </p>
            <p className="text-sm text-muted">{error}</p>
            <button type="button" className="btn-primary" onClick={() => void reload()}>
              {tx('إعادة المحاولة', 'Try again')}
            </button>
          </div>
        )}
        {status === 'ready' && resolvePage(path)}
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <PreferencesProvider>
      <NavigationProvider>
        <CatalogProvider>
          <CartProvider>
            <StoreShell />
          </CartProvider>
        </CatalogProvider>
      </NavigationProvider>
    </PreferencesProvider>
  );
}
