import { useEffect, useState, type FormEvent } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { deletePromoCode, fetchPromoCodes, fetchSettings, savePromoCode, saveSettings } from '@/lib/storeApi';
import type { PromoCode, SiteSettings } from '@/types/store';

const SETTING_FIELDS: { key: string; ar: string; en: string; multiline?: boolean }[] = [
  { key: 'announcement_ar', ar: 'شريط الإعلان (عربي)', en: 'Announcement bar (Arabic)', multiline: true },
  { key: 'announcement_en', ar: 'شريط الإعلان (إنجليزي)', en: 'Announcement bar (English)', multiline: true },
  { key: 'address_ar', ar: 'العنوان (عربي)', en: 'Address (Arabic)' },
  { key: 'address_en', ar: 'العنوان (إنجليزي)', en: 'Address (English)' },
  { key: 'hours_main_ar', ar: 'ساعات السبت - الخميس (عربي)', en: 'Sat - Thu hours (Arabic)' },
  { key: 'hours_main_en', ar: 'ساعات السبت - الخميس (إنجليزي)', en: 'Sat - Thu hours (English)' },
  { key: 'hours_friday_ar', ar: 'ساعات الجمعة (عربي)', en: 'Friday hours (Arabic)' },
  { key: 'hours_friday_en', ar: 'ساعات الجمعة (إنجليزي)', en: 'Friday hours (English)' },
  { key: 'shipping_fee', ar: 'رسوم الشحن (ر.س)', en: 'Shipping fee (SAR)' },
  { key: 'free_shipping_threshold', ar: 'حد الشحن المجاني (ر.س)', en: 'Free shipping threshold (SAR)' },
];

export default function AdminCms() {
  const { tx } = usePreferences();
  const { reload } = useCatalog();
  const [settings, setSettings] = useState<SiteSettings>({});
  const [promos, setPromos] = useState<PromoCode[]>([]);
  const [newCode, setNewCode] = useState({ code: '', percent: '10' });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadAll = async () => {
    try {
      const [s, p] = await Promise.all([fetchSettings(), fetchPromoCodes()]);
      setSettings(s);
      setPromos(p);
      setError(null);
    } catch {
      setError(tx('تعذر تحميل البيانات', 'Could not load data'));
    }
  };

  useEffect(() => {
    void loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveAll = async (event: FormEvent) => {
    event.preventDefault();
    setMessage(null);
    try {
      const entries = Object.fromEntries(SETTING_FIELDS.map((f) => [f.key, settings[f.key] ?? '']));
      await saveSettings(entries);
      await reload();
      setMessage(tx('تم حفظ المحتوى', 'Content saved'));
    } catch {
      setError(tx('تعذر حفظ المحتوى', 'Could not save content'));
    }
  };

  const addPromo = async (event: FormEvent) => {
    event.preventDefault();
    const percent = Number(newCode.percent);
    const code = newCode.code.trim().toUpperCase();
    if (!code || !Number.isInteger(percent) || percent < 1 || percent > 100) {
      setError(tx('أدخل كوداً ونسبة خصم بين 1 و 100', 'Enter a code and a discount between 1 and 100'));
      return;
    }
    try {
      await savePromoCode({ code, percent, active: true });
      setNewCode({ code: '', percent: '10' });
      setError(null);
      await loadAll();
    } catch {
      setError(tx('تعذر حفظ الكود', 'Could not save the code'));
    }
  };

  const togglePromo = async (promo: PromoCode) => {
    try {
      await savePromoCode({ ...promo, active: !promo.active });
      await loadAll();
    } catch {
      setError(tx('تعذر تحديث الكود', 'Could not update the code'));
    }
  };

  const removePromo = async (code: string) => {
    try {
      await deletePromoCode(code);
      await loadAll();
    } catch {
      setError(tx('تعذر حذف الكود', 'Could not delete the code'));
    }
  };

  return (
    <div className="grid gap-8 lg:grid-cols-5">
      <form onSubmit={saveAll} className="card-luxe space-y-5 p-6 lg:col-span-3">
        <h2 className="text-xl font-bold">{tx('محتوى الموقع', 'Site content')}</h2>
        <div className="grid gap-5 sm:grid-cols-2">
          {SETTING_FIELDS.map((field) => (
            <label key={field.key} className={`space-y-1.5 ${field.multiline ? 'sm:col-span-2' : ''}`}>
              <span className="text-xs font-semibold text-muted">{tx(field.ar, field.en)}</span>
              {field.multiline ? (
                <textarea
                  rows={2}
                  className="input-luxe resize-none"
                  value={settings[field.key] ?? ''}
                  onChange={(e) => setSettings((s) => ({ ...s, [field.key]: e.target.value }))}
                />
              ) : (
                <input
                  className="input-luxe"
                  value={settings[field.key] ?? ''}
                  onChange={(e) => setSettings((s) => ({ ...s, [field.key]: e.target.value }))}
                />
              )}
            </label>
          ))}
        </div>
        <div className="flex items-center gap-4">
          <button type="submit" className="btn-gold">{tx('حفظ المحتوى', 'Save content')}</button>
          {message && <span className="text-sm font-semibold text-emerald">{message}</span>}
        </div>
      </form>

      <section className="card-luxe space-y-5 p-6 lg:col-span-2">
        <h2 className="text-xl font-bold">{tx('أكواد الخصم', 'Promo codes')}</h2>
        <form onSubmit={addPromo} className="flex flex-wrap gap-2">
          <input
            className="input-luxe w-auto flex-1 uppercase"
            placeholder={tx('الكود', 'Code')}
            value={newCode.code}
            onChange={(e) => setNewCode((n) => ({ ...n, code: e.target.value }))}
          />
          <input
            className="input-luxe w-24"
            type="number"
            min={1}
            max={100}
            value={newCode.percent}
            onChange={(e) => setNewCode((n) => ({ ...n, percent: e.target.value }))}
            aria-label={tx('نسبة الخصم', 'Discount percent')}
          />
          <button type="submit" className="btn-outline py-2.5">
            <Plus size={16} />
            {tx('إضافة', 'Add')}
          </button>
        </form>
        <ul className="divide-y divide-line">
          {promos.map((promo) => (
            <li key={promo.code} className="flex items-center justify-between gap-3 py-3">
              <div>
                <p className="font-mono font-bold">{promo.code}</p>
                <p className="text-xs text-muted">{promo.percent}%</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void togglePromo(promo)}
                  className={`rounded-full px-3 py-1.5 text-xs font-bold ${
                    promo.active ? 'bg-emerald/15 text-emerald' : 'bg-surface-2 text-muted'
                  }`}
                >
                  {promo.active ? tx('فعّال', 'Active') : tx('متوقف', 'Inactive')}
                </button>
                <button type="button" onClick={() => void removePromo(promo.code)} className="icon-btn h-9 w-9 hover:text-red-500" aria-label={tx('حذف', 'Delete')}>
                  <Trash2 size={15} />
                </button>
              </div>
            </li>
          ))}
        </ul>
        {error && <p className="text-sm font-semibold text-red-500">{error}</p>}
      </section>
    </div>
  );
}
