import { useCallback, useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { fetchOrders, setOrderStatus } from '@/lib/storeApi';
import { formatDateTime, formatPrice } from '@/lib/format';
import type { Order, OrderStatus } from '@/types/store';

const REFRESH_MS = 30000;

const STATUS_META: Record<OrderStatus, { ar: string; en: string; dot: string }> = {
  new: { ar: 'جديد', en: 'New', dot: 'bg-amber-400' },
  preparing: { ar: 'قيد التجهيز', en: 'Preparing', dot: 'bg-sky-500' },
  delivered: { ar: 'تم التوصيل', en: 'Delivered', dot: 'bg-emerald' },
  cancelled: { ar: 'ملغي', en: 'Cancelled', dot: 'bg-red-500' },
};

export default function AdminOrders() {
  const { tx, lang } = usePreferences();
  const { reload } = useCatalog();
  const [orders, setOrders] = useState<Order[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      setOrders(await fetchOrders());
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'UNKNOWN_ERROR');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => void load(), REFRESH_MS);
    return () => window.clearInterval(timer);
  }, [load]);

  const changeStatus = async (order: Order, status: OrderStatus) => {
    setBusyId(order.id);
    setError(null);
    try {
      await setOrderStatus(order.id, status);
      await Promise.all([load(), reload()]);
    } catch (err) {
      const message = err instanceof Error ? err.message : '';
      setError(
        message.startsWith('OUT_OF_STOCK')
          ? tx('لا يوجد مخزون كافٍ لإعادة فتح هذا الطلب', 'Not enough stock to reopen this order')
          : tx('تعذر تحديث حالة الطلب', 'Could not update the order status'),
      );
    } finally {
      setBusyId(null);
    }
  };

  const counts = (Object.keys(STATUS_META) as OrderStatus[]).map((status) => ({
    status,
    count: orders.filter((o) => o.status === status).length,
  }));

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h2 className="text-2xl font-bold">{tx('مسار الطلبات', 'Orders pipeline')}</h2>
        <button type="button" onClick={() => void load()} className="btn-outline py-2 text-sm">
          <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
          {tx('تحديث', 'Refresh')}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {counts.map(({ status, count }) => (
          <div key={status} className="card-luxe p-5">
            <p className="flex items-center gap-2 text-sm text-muted">
              <span className={`h-2.5 w-2.5 rounded-full ${STATUS_META[status].dot}`} />
              {tx(STATUS_META[status].ar, STATUS_META[status].en)}
            </p>
            <p className="mt-2 text-3xl font-bold">{count}</p>
          </div>
        ))}
      </div>

      {error && <p className="text-sm font-semibold text-red-500">{error}</p>}

      <div className="card-luxe overflow-x-auto p-0">
        <table className="w-full min-w-[760px] text-sm">
          <thead className="border-b border-line bg-surface-2 text-start text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-4 py-3 text-start">{tx('رقم الطلب', 'Order ID')}</th>
              <th className="px-4 py-3 text-start">{tx('التاريخ', 'Date')}</th>
              <th className="px-4 py-3 text-start">{tx('المنتجات', 'Items')}</th>
              <th className="px-4 py-3 text-start">{tx('الإجمالي', 'Total')}</th>
              <th className="px-4 py-3 text-start">{tx('الحالة', 'Status')}</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3 font-mono text-xs font-bold">{order.order_number}</td>
                <td className="px-4 py-3 text-muted">{formatDateTime(order.created_at, lang)}</td>
                <td className="max-w-xs px-4 py-3">
                  <ul className="space-y-1">
                    {order.items.map((item) => (
                      <li key={`${item.product_id}-${item.flavor?.en ?? ''}-${item.nicotine ?? ''}`} className="truncate text-xs">
                        {lang === 'ar' ? item.name_ar : item.name_en} x{item.qty}
                        {item.flavor && ` · ${lang === 'ar' ? item.flavor.ar : item.flavor.en}`}
                        {item.nicotine && ` · ${item.nicotine}`}
                      </li>
                    ))}
                  </ul>
                </td>
                <td className="px-4 py-3 font-bold text-gold-text">{formatPrice(order.total, lang)}</td>
                <td className="px-4 py-3">
                  <select
                    value={order.status}
                    disabled={busyId === order.id}
                    onChange={(e) => void changeStatus(order, e.target.value as OrderStatus)}
                    className="input-luxe w-auto py-2 text-xs"
                    aria-label={tx('حالة الطلب', 'Order status')}
                  >
                    {(Object.keys(STATUS_META) as OrderStatus[]).map((status) => (
                      <option key={status} value={status}>
                        {tx(STATUS_META[status].ar, STATUS_META[status].en)}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {!loading && orders.length === 0 && (
          <p className="py-16 text-center text-muted">{tx('لا توجد طلبات بعد', 'No orders yet')}</p>
        )}
      </div>
    </div>
  );
}
