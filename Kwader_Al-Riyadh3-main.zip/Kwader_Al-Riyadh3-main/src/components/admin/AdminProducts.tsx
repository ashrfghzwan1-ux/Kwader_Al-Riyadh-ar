import { useMemo, useState } from 'react';
import { Pencil, Plus, Search, Trash2 } from 'lucide-react';
import ProductFormModal from '@/components/admin/ProductFormModal';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { formatPrice } from '@/lib/format';
import { deleteProduct, updateProductStock } from '@/lib/storeApi';
import type { Product } from '@/types/store';

const PAGE_SIZE = 40;

export default function AdminProducts() {
  const { tx, lang } = usePreferences();
  const { products, categories, reload } = useCatalog();
  const [search, setSearch] = useState('');
  const [visible, setVisible] = useState(PAGE_SIZE);
  const [editing, setEditing] = useState<Product | null | 'new'>(null);
  const [error, setError] = useState<string | null>(null);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter((p) => !q || `${p.id} ${p.name_ar} ${p.name_en}`.toLowerCase().includes(q));
  }, [products, search]);

  const categoryName = (id: string) => {
    const c = categories.find((cat) => cat.id === id);
    return c ? tx(c.name_ar, c.name_en) : id;
  };

  const saveStock = async (product: Product, value: string) => {
    const stock = Number(value);
    if (!Number.isInteger(stock) || stock < 0 || stock === product.stock) return;
    setError(null);
    try {
      await updateProductStock(product.id, stock);
      await reload();
    } catch {
      setError(tx('تعذر تحديث المخزون', 'Could not update stock'));
    }
  };

  const remove = async (product: Product) => {
    if (!window.confirm(tx(`حذف "${product.name_ar}" نهائياً؟`, `Delete "${product.name_en}" permanently?`))) return;
    setError(null);
    try {
      await deleteProduct(product.id);
      await reload();
    } catch {
      setError(tx('تعذر حذف المنتج', 'Could not delete the product'));
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">{tx('إدارة المنتجات والمخزون', 'Products & stock')}</h2>
          <p className="mt-1 text-sm text-muted">{tx(`${products.length} منتج`, `${products.length} products`)}</p>
        </div>
        <button type="button" onClick={() => setEditing('new')} className="btn-gold py-2.5 text-sm">
          <Plus size={16} />
          {tx('منتج جديد', 'New product')}
        </button>
      </div>

      <div className="relative max-w-md">
        <Search size={16} className="pointer-events-none absolute start-4 top-1/2 -translate-y-1/2 text-muted" />
        <input
          type="search"
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setVisible(PAGE_SIZE);
          }}
          placeholder={tx('ابحث بالاسم أو الرقم...', 'Search by name or ID...')}
          className="input-luxe ps-11"
        />
      </div>

      {error && <p className="text-sm font-semibold text-red-500">{error}</p>}

      <div className="card-luxe overflow-x-auto p-0">
        <table className="w-full min-w-[800px] text-sm">
          <thead className="border-b border-line bg-surface-2 text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-4 py-3 text-start">{tx('المنتج', 'Product')}</th>
              <th className="px-4 py-3 text-start">{tx('القسم', 'Category')}</th>
              <th className="px-4 py-3 text-start">{tx('السعر', 'Price')}</th>
              <th className="px-4 py-3 text-start">{tx('المخزون', 'Stock')}</th>
              <th className="px-4 py-3 text-end">{tx('إجراءات', 'Actions')}</th>
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, visible).map((product) => (
              <tr key={product.id} className="border-b border-line last:border-0">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <img src={product.image_url} alt="" className="h-10 w-10 rounded-lg object-cover" loading="lazy" />
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{lang === 'ar' ? product.name_ar : product.name_en}</p>
                      <p className="font-mono text-[0.7rem] text-muted">{product.id}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-muted">{categoryName(product.category_id)}</td>
                <td className="px-4 py-3 font-semibold">{formatPrice(product.price, lang)}</td>
                <td className="px-4 py-3">
                  <input
                    type="number"
                    min={0}
                    defaultValue={product.stock}
                    key={`${product.id}-${product.stock}`}
                    onBlur={(e) => void saveStock(product, e.target.value)}
                    className={`input-luxe w-24 py-2 text-center ${product.stock === 0 ? 'border-red-500/60' : ''}`}
                    aria-label={tx('المخزون', 'Stock')}
                  />
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-2">
                    <button type="button" onClick={() => setEditing(product)} className="icon-btn h-9 w-9" aria-label={tx('تعديل', 'Edit')}>
                      <Pencil size={15} />
                    </button>
                    <button
                      type="button"
                      onClick={() => void remove(product)}
                      className="icon-btn h-9 w-9 hover:text-red-500"
                      aria-label={tx('حذف', 'Delete')}
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {visible < rows.length && (
        <div className="flex justify-center">
          <button type="button" onClick={() => setVisible((v) => v + PAGE_SIZE)} className="btn-outline">
            {tx('عرض المزيد', 'Show more')}
          </button>
        </div>
      )}

      {editing !== null && (
        <ProductFormModal
          product={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            void reload();
          }}
        />
      )}
    </div>
  );
}
