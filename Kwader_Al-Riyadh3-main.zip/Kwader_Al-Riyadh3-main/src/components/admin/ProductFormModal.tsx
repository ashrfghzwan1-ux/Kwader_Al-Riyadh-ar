import { useState, type FormEvent } from 'react';
import Modal from '@/components/common/Modal';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { NICOTINE_LEVELS } from '@/lib/constants';
import { saveProduct } from '@/lib/storeApi';
import type { Product } from '@/types/store';

interface ProductFormModalProps {
  product: Product | null;
  onClose: () => void;
  onSaved: () => void;
}

interface FormState {
  name_ar: string;
  name_en: string;
  category_id: string;
  price: string;
  compare_at_price: string;
  stock: string;
  image_url: string;
  description_ar: string;
  description_en: string;
  nicotine_levels: string[];
}

function toForm(product: Product | null, fallbackCategory: string): FormState {
  return {
    name_ar: product?.name_ar ?? '',
    name_en: product?.name_en ?? '',
    category_id: product?.category_id ?? fallbackCategory,
    price: String(product?.price ?? ''),
    compare_at_price: product?.compare_at_price ? String(product.compare_at_price) : '',
    stock: String(product?.stock ?? 0),
    image_url: product?.image_url ?? '',
    description_ar: product?.description_ar ?? '',
    description_en: product?.description_en ?? '',
    nicotine_levels: product?.nicotine_levels ?? [],
  };
}

export default function ProductFormModal({ product, onClose, onSaved }: ProductFormModalProps) {
  const { tx } = usePreferences();
  const { categories } = useCatalog();
  const [form, setForm] = useState<FormState>(() => toForm(product, categories[0]?.id ?? ''));
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((f) => ({ ...f, [key]: value }));

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    const price = Number(form.price);
    const compare = form.compare_at_price ? Number(form.compare_at_price) : null;
    const stock = Number(form.stock);
    if (!form.name_ar.trim() || !form.name_en.trim()) {
      setError(tx('الاسم بالعربية والإنجليزية مطلوب', 'Arabic and English names are required'));
      return;
    }
    if (!Number.isFinite(price) || price < 0 || (compare !== null && (!Number.isFinite(compare) || compare < 0))) {
      setError(tx('السعر غير صالح', 'Invalid price'));
      return;
    }
    if (!Number.isInteger(stock) || stock < 0) {
      setError(tx('المخزون يجب أن يكون رقماً صحيحاً', 'Stock must be a whole number'));
      return;
    }

    setBusy(true);
    setError(null);
    try {
      await saveProduct({
        id: product?.id ?? `KW-${Date.now().toString(36).toUpperCase()}`,
        category_id: form.category_id,
        name_ar: form.name_ar.trim(),
        name_en: form.name_en.trim(),
        description_ar: form.description_ar,
        description_en: form.description_en,
        price,
        compare_at_price: compare,
        stock,
        image_url: form.image_url.trim(),
        flavor_profile: product?.flavor_profile ?? 'none',
        flavor_options: product?.flavor_options ?? [],
        nicotine_levels: form.nicotine_levels,
      });
      onSaved();
    } catch {
      setError(tx('تعذر حفظ المنتج', 'Could not save the product'));
    } finally {
      setBusy(false);
    }
  };

  const field = 'space-y-1.5';
  const label = 'text-xs font-semibold text-muted';

  return (
    <Modal open onClose={onClose} title={product ? tx('تعديل المنتج', 'Edit product') : tx('منتج جديد', 'New product')} size="lg">
      <form onSubmit={submit} className="grid gap-5 sm:grid-cols-2">
        <label className={field}>
          <span className={label}>{tx('الاسم (عربي)', 'Name (Arabic)')}</span>
          <input className="input-luxe" value={form.name_ar} onChange={(e) => set('name_ar', e.target.value)} />
        </label>
        <label className={field}>
          <span className={label}>{tx('الاسم (إنجليزي)', 'Name (English)')}</span>
          <input className="input-luxe" value={form.name_en} onChange={(e) => set('name_en', e.target.value)} />
        </label>
        <label className={field}>
          <span className={label}>{tx('القسم', 'Category')}</span>
          <select className="input-luxe" value={form.category_id} onChange={(e) => set('category_id', e.target.value)}>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {tx(c.name_ar, c.name_en)}
              </option>
            ))}
          </select>
        </label>
        <label className={field}>
          <span className={label}>{tx('رابط الصورة', 'Image URL')}</span>
          <input className="input-luxe" dir="ltr" value={form.image_url} onChange={(e) => set('image_url', e.target.value)} />
        </label>
        <label className={field}>
          <span className={label}>{tx('السعر (ر.س)', 'Price (SAR)')}</span>
          <input className="input-luxe" type="number" min="0" step="0.01" value={form.price} onChange={(e) => set('price', e.target.value)} />
        </label>
        <label className={field}>
          <span className={label}>{tx('السعر قبل الخصم (اختياري)', 'Compare-at price (optional)')}</span>
          <input className="input-luxe" type="number" min="0" step="0.01" value={form.compare_at_price} onChange={(e) => set('compare_at_price', e.target.value)} />
        </label>
        <label className={field}>
          <span className={label}>{tx('المخزون', 'Stock')}</span>
          <input className="input-luxe" type="number" min="0" step="1" value={form.stock} onChange={(e) => set('stock', e.target.value)} />
        </label>
        <div className={field}>
          <span className={label}>{tx('قوة النيكوتين', 'Nicotine levels')}</span>
          <div className="flex flex-wrap gap-2">
            {NICOTINE_LEVELS.map((level) => {
              const active = form.nicotine_levels.includes(level);
              return (
                <button
                  key={level}
                  type="button"
                  aria-pressed={active}
                  onClick={() =>
                    set('nicotine_levels', active ? form.nicotine_levels.filter((l) => l !== level) : [...form.nicotine_levels, level])
                  }
                  className={`rounded-lg border px-3 py-1.5 text-xs font-bold ${active ? 'border-emerald bg-emerald text-white' : 'border-line'}`}
                >
                  {level}
                </button>
              );
            })}
          </div>
        </div>
        <label className={`${field} sm:col-span-2`}>
          <span className={label}>{tx('الوصف (عربي)', 'Description (Arabic)')}</span>
          <textarea rows={2} className="input-luxe resize-none" value={form.description_ar} onChange={(e) => set('description_ar', e.target.value)} />
        </label>
        <label className={`${field} sm:col-span-2`}>
          <span className={label}>{tx('الوصف (إنجليزي)', 'Description (English)')}</span>
          <textarea rows={2} className="input-luxe resize-none" value={form.description_en} onChange={(e) => set('description_en', e.target.value)} />
        </label>
        {error && <p className="text-sm font-semibold text-red-500 sm:col-span-2">{error}</p>}
        <div className="flex justify-end gap-3 sm:col-span-2">
          <button type="button" onClick={onClose} className="btn-outline">
            {tx('إلغاء', 'Cancel')}
          </button>
          <button type="submit" disabled={busy} className="btn-gold">
            {busy ? tx('جارٍ الحفظ...', 'Saving...') : tx('حفظ', 'Save')}
          </button>
        </div>
      </form>
    </Modal>
  );
}
