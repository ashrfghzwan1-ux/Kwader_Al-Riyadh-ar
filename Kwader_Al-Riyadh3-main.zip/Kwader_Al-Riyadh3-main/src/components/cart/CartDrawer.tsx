import { useState, type FormEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, MessageCircle, ShoppingBag, Tag, X } from 'lucide-react';
import CartItemRow from '@/components/cart/CartItemRow';
import AppLink from '@/components/common/AppLink';
import { useCart } from '@/context/CartContext';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { formatPrice } from '@/lib/format';
import { buildOrderMessage, buildWhatsappUrl } from '@/lib/whatsapp';
import type { Order } from '@/types/store';

function describeCheckoutError(message: string, tx: <T>(ar: T, en: T) => T): string {
  if (message.startsWith('OUT_OF_STOCK')) {
    return tx('بعض المنتجات لم تعد متوفرة بالكمية المطلوبة. يرجى تحديث السلة.', 'Some items no longer have enough stock. Please update your cart.');
  }
  if (message === 'INVALID_COUPON') return tx('كود الخصم غير صالح', 'This coupon code is not valid');
  if (message === 'EMPTY_CART') return tx('السلة فارغة', 'Your cart is empty');
  return tx('تعذر إتمام الطلب، يرجى المحاولة مرة أخرى', 'We could not place your order. Please try again.');
}

export default function CartDrawer() {
  const cart = useCart();
  const { freeShippingThreshold } = useCatalog();
  const { tx, lang } = usePreferences();
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);
  const [couponBusy, setCouponBusy] = useState(false);
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  const [checkoutError, setCheckoutError] = useState<string | null>(null);
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);

  const progress =
    freeShippingThreshold > 0 ? Math.min(1, (freeShippingThreshold - cart.freeShippingRemaining) / freeShippingThreshold) : 1;

  const handleApplyCoupon = async (event: FormEvent) => {
    event.preventDefault();
    if (!couponInput.trim()) return;
    setCouponBusy(true);
    setCouponError(null);
    try {
      await cart.applyCoupon(couponInput);
      setCouponInput('');
    } catch (err) {
      setCouponError(describeCheckoutError(err instanceof Error ? err.message : '', tx));
    } finally {
      setCouponBusy(false);
    }
  };

  const handleCheckout = async () => {
    setCheckoutBusy(true);
    setCheckoutError(null);
    try {
      const order = await cart.checkout();
      setPlacedOrder(order);
      window.open(buildWhatsappUrl(buildOrderMessage(order, lang)), '_blank', 'noopener,noreferrer');
    } catch (err) {
      setCheckoutError(describeCheckoutError(err instanceof Error ? err.message : '', tx));
    } finally {
      setCheckoutBusy(false);
    }
  };

  const closeAfterOrder = () => {
    setPlacedOrder(null);
    cart.closeCart();
  };

  return (
    <AnimatePresence>
      {cart.isOpen && (
        <div className="fixed inset-0 z-[65]">
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={cart.closeCart}
          />
          <motion.aside
            role="dialog"
            aria-modal="true"
            aria-label={tx('سلة التسوق', 'Shopping cart')}
            className="absolute inset-y-0 end-0 flex w-full flex-col bg-surface shadow-lift sm:w-[440px] sm:border-s sm:border-line"
            initial={{ x: lang === 'ar' ? '-100%' : '100%' }}
            animate={{ x: 0 }}
            exit={{ x: lang === 'ar' ? '-100%' : '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          >
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h2 className="flex items-center gap-2 text-lg font-bold">
                <ShoppingBag size={20} className="text-gold-text" />
                {tx('سلة التسوق', 'Shopping cart')}
                <span className="text-sm font-normal text-muted">({cart.count})</span>
              </h2>
              <button type="button" onClick={cart.closeCart} className="icon-btn" aria-label={tx('إغلاق', 'Close')}>
                <X size={18} />
              </button>
            </div>

            {placedOrder ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center">
                <span className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald/15 text-emerald">
                  <CheckCircle2 size={34} />
                </span>
                <div className="space-y-2">
                  <p className="text-xl font-bold">{tx('تم تسجيل طلبك', 'Your order is recorded')}</p>
                  <p className="text-sm text-muted">
                    {tx('رقم الطلب', 'Order number')}: <span className="font-bold text-ink">{placedOrder.order_number}</span>
                  </p>
                  <p className="text-sm text-muted">
                    {tx(
                      'أرسل الرسالة عبر الواتساب لتأكيد الطلب مع فريقنا.',
                      'Send the message on WhatsApp to confirm the order with our team.',
                    )}
                  </p>
                </div>
                <a
                  href={buildWhatsappUrl(buildOrderMessage(placedOrder, lang))}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-gold w-full"
                >
                  <MessageCircle size={18} />
                  {tx('إرسال عبر الواتساب', 'Send via WhatsApp')}
                </a>
                <AppLink to="/catalog" onNavigate={closeAfterOrder} className="text-sm font-semibold text-gold-text">
                  {tx('متابعة التسوق', 'Continue shopping')}
                </AppLink>
              </div>
            ) : cart.items.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center">
                <ShoppingBag size={48} className="text-muted" />
                <p className="font-semibold">{tx('سلتك فارغة حالياً', 'Your cart is empty')}</p>
                <AppLink to="/catalog" onNavigate={cart.closeCart} className="btn-primary">
                  {tx('تصفح المنتجات', 'Browse products')}
                </AppLink>
              </div>
            ) : (
              <>
                <div className="space-y-2 border-b border-line px-5 py-4">
                  <p className="text-sm font-semibold">
                    {cart.freeShippingRemaining > 0
                      ? tx(
                          `أضف بـ ${formatPrice(cart.freeShippingRemaining, lang)} أخرى للحصول على شحن مجاني`,
                          `Add ${formatPrice(cart.freeShippingRemaining, lang)} more for free shipping`,
                        )
                      : tx('مبروك! حصلت على شحن مجاني', 'Congrats! You unlocked free shipping')}
                  </p>
                  <div className="h-2 overflow-hidden rounded-full bg-surface-2">
                    <motion.div
                      className="h-full rounded-full bg-gradient-to-l from-gold to-emerald"
                      initial={{ width: 0 }}
                      animate={{ width: `${progress * 100}%` }}
                      transition={{ duration: 0.6, ease: 'easeOut' }}
                    />
                  </div>
                </div>

                <ul className="flex-1 space-y-3 overflow-y-auto px-5 py-4">
                  {cart.items.map((item) => (
                    <CartItemRow key={item.key} item={item} />
                  ))}
                </ul>

                <div className="space-y-4 border-t border-line px-5 py-4">
                  {cart.coupon ? (
                    <div className="flex items-center justify-between rounded-xl border border-emerald/40 bg-emerald/10 px-4 py-2.5 text-sm">
                      <span className="flex items-center gap-2 font-semibold">
                        <Tag size={15} className="text-emerald" />
                        {cart.coupon.code} (-{cart.coupon.percent}%)
                      </span>
                      <button type="button" onClick={cart.removeCoupon} className="text-xs font-semibold text-muted hover:text-ink">
                        {tx('إزالة', 'Remove')}
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleApplyCoupon} className="flex gap-2">
                      <input
                        value={couponInput}
                        onChange={(e) => setCouponInput(e.target.value)}
                        placeholder={tx('كود الخصم', 'Coupon code')}
                        className="input-luxe py-2.5 uppercase"
                        aria-label={tx('كود الخصم', 'Coupon code')}
                      />
                      <button type="submit" disabled={couponBusy || !couponInput.trim()} className="btn-outline shrink-0">
                        {tx('تطبيق', 'Apply')}
                      </button>
                    </form>
                  )}
                  {couponError && <p className="text-xs font-semibold text-red-500">{couponError}</p>}

                  <dl className="space-y-1.5 text-sm">
                    <Row label={tx('المجموع الفرعي', 'Subtotal')} value={formatPrice(cart.subtotal, lang)} />
                    {cart.discount > 0 && (
                      <Row label={tx('الخصم', 'Discount')} value={`-${formatPrice(cart.discount, lang)}`} accent />
                    )}
                    <Row
                      label={tx('الشحن', 'Shipping')}
                      value={cart.shipping > 0 ? formatPrice(cart.shipping, lang) : tx('مجاني', 'Free')}
                    />
                    <div className="flex items-center justify-between border-t border-line pt-3 text-base font-bold">
                      <dt>{tx('الإجمالي', 'Total')}</dt>
                      <dd className="text-gold-text">{formatPrice(cart.total, lang)}</dd>
                    </div>
                  </dl>

                  {checkoutError && <p className="text-xs font-semibold text-red-500">{checkoutError}</p>}
                  <button
                    type="button"
                    onClick={handleCheckout}
                    disabled={checkoutBusy}
                    className="btn-gold w-full py-3.5"
                  >
                    <MessageCircle size={18} />
                    {checkoutBusy
                      ? tx('جارٍ تسجيل الطلب...', 'Placing order...')
                      : tx('تأكيد الطلب وإرسال عبر الواتساب', 'Confirm order and send via WhatsApp')}
                  </button>
                </div>
              </>
            )}
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}

function Row({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex items-center justify-between text-muted">
      <dt>{label}</dt>
      <dd className={accent ? 'font-semibold text-emerald' : 'font-semibold text-ink'}>{value}</dd>
    </div>
  );
}
