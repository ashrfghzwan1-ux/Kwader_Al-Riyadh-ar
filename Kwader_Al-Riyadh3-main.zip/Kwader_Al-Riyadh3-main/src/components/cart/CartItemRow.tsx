import { Minus, Plus, Trash2 } from 'lucide-react';
import type { CartItemView } from '@/context/CartContext';
import { usePreferences } from '@/context/PreferencesContext';
import { useCart } from '@/context/CartContext';
import { formatPrice } from '@/lib/format';
import type { FlavorOption } from '@/types/store';

interface CartItemRowProps {
  item: CartItemView;
}

export default function CartItemRow({ item }: CartItemRowProps) {
  const { tx, lang } = usePreferences();
  const { changeQty, changeOptions, removeItem } = useCart();
  const { line, product } = item;
  const name = lang === 'ar' ? product.name_ar : product.name_en;
  const atStockLimit = line.qty >= product.stock;

  const pickFlavor = (flavor: FlavorOption) => changeOptions(item.key, { flavor, nicotine: line.nicotine });
  const pickNicotine = (nicotine: string) => changeOptions(item.key, { flavor: line.flavor, nicotine });

  return (
    <li className="flex gap-4 rounded-2xl border border-line bg-bg p-3">
      <img
        src={product.image_url}
        alt={name}
        loading="lazy"
        className="h-20 w-20 shrink-0 rounded-xl object-cover"
      />
      <div className="flex min-w-0 flex-1 flex-col gap-2">
        <div className="flex items-start justify-between gap-2">
          <p className="line-clamp-2 text-sm font-semibold leading-snug">{name}</p>
          <button
            type="button"
            onClick={() => removeItem(item.key)}
            className="shrink-0 text-muted transition hover:text-red-500"
            aria-label={tx('حذف المنتج', 'Remove item')}
          >
            <Trash2 size={16} />
          </button>
        </div>

        {product.flavor_options.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {product.flavor_options.map((option) => {
              const active = line.flavor?.en === option.en;
              return (
                <button
                  key={option.en}
                  type="button"
                  onClick={() => pickFlavor(option)}
                  aria-pressed={active}
                  className={`rounded-full border px-2.5 py-0.5 text-[0.7rem] font-semibold transition ${
                    active ? 'border-gold bg-gold text-black' : 'border-line text-muted hover:border-gold'
                  }`}
                >
                  {tx(option.ar, option.en)}
                </button>
              );
            })}
          </div>
        )}

        {product.nicotine_levels.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {product.nicotine_levels.map((level) => {
              const active = line.nicotine === level;
              return (
                <button
                  key={level}
                  type="button"
                  onClick={() => pickNicotine(level)}
                  aria-pressed={active}
                  className={`rounded-md border px-2 py-0.5 text-[0.7rem] font-bold transition ${
                    active ? 'border-emerald bg-emerald text-white' : 'border-line text-muted hover:border-emerald'
                  }`}
                >
                  {level}
                </button>
              );
            })}
          </div>
        )}

        <div className="mt-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-1 rounded-full border border-line bg-surface p-1">
            <button
              type="button"
              onClick={() => changeQty(item.key, -1)}
              className="flex h-7 w-7 items-center justify-center rounded-full transition hover:text-gold-text"
              aria-label={tx('تقليل الكمية', 'Decrease quantity')}
            >
              <Minus size={14} />
            </button>
            <span className="w-6 text-center text-sm font-bold">{line.qty}</span>
            <button
              type="button"
              onClick={() => changeQty(item.key, 1)}
              disabled={atStockLimit}
              className="flex h-7 w-7 items-center justify-center rounded-full transition hover:text-gold-text disabled:opacity-40"
              aria-label={tx('زيادة الكمية', 'Increase quantity')}
            >
              <Plus size={14} />
            </button>
          </div>
          <span className="text-sm font-bold text-gold-text">{formatPrice(product.price * line.qty, lang)}</span>
        </div>
      </div>
    </li>
  );
}
