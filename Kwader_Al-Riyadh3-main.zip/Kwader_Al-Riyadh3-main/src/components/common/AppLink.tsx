import type { MouseEvent, ReactNode } from 'react';
import { useNavigation } from '@/context/NavigationContext';

interface AppLinkProps {
  to: string;
  className?: string;
  onNavigate?: () => void;
  children: ReactNode;
}

export default function AppLink({ to, className, onNavigate, children }: AppLinkProps) {
  const { navigate } = useNavigation();

  const handleClick = (event: MouseEvent<HTMLAnchorElement>) => {
    if (event.metaKey || event.ctrlKey || event.shiftKey) return;
    event.preventDefault();
    onNavigate?.();
    navigate(to);
  };

  return (
    <a href={to} className={className} onClick={handleClick}>
      {children}
    </a>
  );
}
