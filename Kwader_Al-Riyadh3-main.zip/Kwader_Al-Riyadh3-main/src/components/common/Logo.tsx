import { Crown } from 'lucide-react';
import { BRAND } from '@/lib/constants';
import { usePreferences } from '@/context/PreferencesContext';

export default function Logo({ compact = false }: { compact?: boolean }) {
  const { tx } = usePreferences();
  return (
    <div className="flex items-center gap-3">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/60 bg-accent text-gold shadow-gold">
        <Crown size={20} strokeWidth={1.75} />
      </span>
      {!compact && (
        <span className="flex min-w-0 flex-col leading-tight">
          <span className="truncate text-sm font-bold text-ink sm:text-base">{tx(BRAND.nameAr, BRAND.nameEn)}</span>
          <span className="truncate text-[0.7rem] tracking-wide text-muted">
            {tx(BRAND.nameEn, BRAND.nameAr)}
          </span>
        </span>
      )}
    </div>
  );
}
