import type { ReactNode } from 'react';

interface PageHeroProps {
  eyebrow: string;
  title: string;
  subtitle?: string;
  image?: string;
  children?: ReactNode;
}

export default function PageHero({ eyebrow, title, subtitle, image, children }: PageHeroProps) {
  return (
    <section className="relative isolate overflow-hidden border-b border-line">
      {image && (
        <>
          <img src={image} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover opacity-25" />
          <div className="absolute inset-0 -z-10 bg-gradient-to-b from-bg/40 via-bg/80 to-bg" />
        </>
      )}
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-24">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-4 max-w-3xl text-4xl font-bold leading-tight sm:text-5xl">{title}</h1>
        {subtitle && <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted sm:text-lg">{subtitle}</p>}
        {children && <div className="mt-8">{children}</div>}
      </div>
    </section>
  );
}
