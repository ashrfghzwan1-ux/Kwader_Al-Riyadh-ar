import type { ReactNode } from 'react';
import { Clock, ExternalLink, MapPin, MessageCircle, Phone } from 'lucide-react';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { BRAND } from '@/lib/constants';
import { buildWhatsappUrl } from '@/lib/whatsapp';

export default function LocationSection() {
  const { tx } = usePreferences();
  const { settings } = useCatalog();
  const address = tx(settings.address_ar, settings.address_en);

  return (
    <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
      <div className="mb-12 text-center">
        <p className="eyebrow">{tx('زورونا', 'Visit us')}</p>
        <h2 className="mt-3 text-3xl font-bold sm:text-4xl">{tx('شرفنا بزيارتك', 'We look forward to your visit')}</h2>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <div className="card-luxe overflow-hidden p-0 lg:col-span-3">
          <iframe
            title={tx('موقع المتجر على الخريطة', 'Store location on the map')}
            src={BRAND.mapEmbedUrl}
            className="h-80 w-full border-0 sm:h-[420px] grayscale-[30%] dark:invert-[0.9] dark:hue-rotate-180"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>

        <div className="grid gap-6 lg:col-span-2">
          <InfoCard icon={<MapPin size={20} />} title={tx('العنوان', 'Address')}>
            <p className="text-sm leading-relaxed text-muted">{address}</p>
            <a
              href={BRAND.mapDirectionsUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-gold-text hover:underline"
            >
              {tx('احصل على الاتجاهات', 'Get directions')}
              <ExternalLink size={14} />
            </a>
          </InfoCard>

          <InfoCard icon={<Phone size={20} />} title={tx('الهاتف والواتساب', 'Phone & WhatsApp')}>
            <p className="text-sm font-semibold" dir="ltr">
              {BRAND.phoneDisplay}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <a href={`tel:${BRAND.phoneTel}`} className="btn-outline">
                <Phone size={15} />
                {tx('اتصال', 'Call')}
              </a>
              <a href={buildWhatsappUrl(tx('مرحباً', 'Hello'))} target="_blank" rel="noreferrer" className="btn-gold">
                <MessageCircle size={15} />
                {tx('واتساب', 'WhatsApp')}
              </a>
            </div>
          </InfoCard>

          <InfoCard icon={<Clock size={20} />} title={tx('ساعات العمل', 'Working hours')}>
            <ul className="space-y-2 text-sm">
              <li className="flex justify-between gap-3">
                <span className="text-muted">{tx('السبت - الخميس', 'Sat - Thu')}</span>
                <span className="font-semibold">{tx(settings.hours_main_ar, settings.hours_main_en)}</span>
              </li>
              <li className="flex justify-between gap-3">
                <span className="text-muted">{tx('الجمعة', 'Friday')}</span>
                <span className="font-semibold">{tx(settings.hours_friday_ar, settings.hours_friday_en)}</span>
              </li>
            </ul>
          </InfoCard>
        </div>
      </div>
    </section>
  );
}

function InfoCard({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <div className="card-luxe p-6">
      <div className="mb-4 flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gold/15 text-gold-text">{icon}</span>
        <h3 className="font-bold">{title}</h3>
      </div>
      {children}
    </div>
  );
}
