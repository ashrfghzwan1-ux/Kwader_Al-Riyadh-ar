import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { BadgeCheck, ChevronLeft, ChevronRight, Star } from 'lucide-react';
import { usePreferences } from '@/context/PreferencesContext';

interface Review {
  quote: { ar: string; en: string };
  name: { ar: string; en: string };
  item: { ar: string; en: string };
  date: string;
}

const REVIEWS: Review[] = [
  {
    quote: {
      ar: 'معسل النخلة جودة ممتازة، النكهة متوازنة وثابتة من أول جلسة حتى آخرها. التغليف أنيق والتوصيل كان سريعاً.',
      en: 'The Palm molasses has excellent quality. The flavor is balanced and consistent from the first session to the last. Elegant packaging and fast delivery.',
    },
    name: { ar: 'أحمد العتيبي', en: 'Ahmed Al-Otaibi' },
    item: { ar: 'معسل فاخر', en: 'Premium Molasses' },
    date: '2026-09-14',
  },
  {
    quote: {
      ar: 'الشيشة النحاسية تصميمها راقٍ جداً وتسحب بسلاسة. الفريق في المحل يساعدك تختار الخلطة المناسبة لذوقك.',
      en: 'The brass hookah is very refined and draws smoothly. The team helps you choose the blend that suits your taste.',
    },
    name: { ar: 'سلطان القحطاني', en: 'Sultan Al-Qahtani' },
    item: { ar: 'شيشة فاخرة', en: 'Luxury Hookah' },
    date: '2026-10-02',
  },
  {
    quote: {
      ar: 'اشتريت الفحم والطبق مع الشيشة، الفحم يشتعل بسرعة ويحافظ على حرارته لوقت طويل. أنصح بالتعامل معهم.',
      en: 'I bought the charcoal and bowl with the hookah. The charcoal lights fast and holds heat for a long time. Highly recommended.',
    },
    name: { ar: 'فهد الدوسري', en: 'Fahad Al-Dosari' },
    item: { ar: 'فحم وطبق', en: 'Charcoal & Bowl' },
    date: '2026-10-21',
  },
  {
    quote: {
      ar: 'السحبة الإلكترونية بعمر بطارية ممتاز والنكهات قريبة جداً من الوصف. خصم كود K01 ساعدني كثيراً.',
      en: 'The disposable vape has excellent battery life and the flavors match the description. The K01 code helped a lot.',
    },
    name: { ar: 'خالد المطيري', en: 'Khalid Al-Mutairi' },
    item: { ar: 'سحبة إلكترونية', en: 'Disposable Vape' },
    date: '2026-11-03',
  },
];

export default function ReviewsCarousel() {
  const { tx, lang } = usePreferences();
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const review = REVIEWS[index];

  useEffect(() => {
    if (paused) return;
    const timer = window.setInterval(() => setIndex((i) => (i + 1) % REVIEWS.length), 6000);
    return () => window.clearInterval(timer);
  }, [paused]);

  const step = (delta: number) => setIndex((i) => (i + delta + REVIEWS.length) % REVIEWS.length);
  const Prev = lang === 'ar' ? ChevronRight : ChevronLeft;
  const Next = lang === 'ar' ? ChevronLeft : ChevronRight;

  return (
    <section className="relative overflow-hidden bg-accent py-20 text-white">
      <div className="pointer-events-none absolute -top-24 start-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-gold/20 blur-3xl" />
      <div className="relative mx-auto max-w-4xl px-4 sm:px-6">
        <div className="mb-10 text-center">
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold">
            {tx('آراء العملاء', 'Testimonials')}
          </p>
          <h2 className="mt-3 text-3xl font-bold sm:text-4xl">{tx('ماذا يقول عملاؤنا', 'What our customers say')}</h2>
        </div>

        <div
          className="glass relative rounded-3xl p-6 sm:p-10"
          style={{ background: 'rgb(255 255 255 / 0.06)', borderColor: 'rgb(255 255 255 / 0.15)' }}
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          <span className="pointer-events-none absolute -top-4 start-8 select-none text-7xl leading-none text-gold/80" aria-hidden="true">
            &rdquo;
          </span>

          <AnimatePresence mode="wait">
            <motion.div
              key={review.name.en}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.35 }}
              className="space-y-6"
            >
              <div className="flex gap-1 text-gold" aria-label={tx('5 من 5 نجوم', '5 out of 5 stars')}>
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={18} className="fill-gold" />
                ))}
              </div>
              <p className="text-lg leading-loose text-white sm:text-xl">{tx(review.quote.ar, review.quote.en)}</p>
              <div className="flex flex-wrap items-center justify-between gap-4 border-t border-white/15 pt-6">
                <div>
                  <p className="font-bold text-white">{tx(review.name.ar, review.name.en)}</p>
                  <p className="mt-1 text-xs text-white/80">
                    {tx('المنتج', 'Purchased')}: <span className="text-gold">{tx(review.item.ar, review.item.en)}</span>
                    {' · '}
                    {new Date(review.date).toLocaleDateString(lang === 'ar' ? 'ar-SA' : 'en-GB', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </p>
                </div>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald/20 px-3 py-1 text-xs font-semibold text-emerald-200">
                  <BadgeCheck size={14} />
                  {tx('مشتري موثق', 'Verified buyer')}
                </span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="mt-8 flex items-center justify-center gap-4">
          <button
            type="button"
            onClick={() => step(-1)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/30 transition hover:bg-white/10"
            aria-label={tx('السابق', 'Previous')}
          >
            <Prev size={18} />
          </button>
          <div className="flex gap-2">
            {REVIEWS.map((r, i) => (
              <button
                key={r.name.en}
                type="button"
                onClick={() => setIndex(i)}
                aria-label={`${i + 1}`}
                className={`h-2 rounded-full transition-all ${i === index ? 'w-8 bg-gold' : 'w-2 bg-white/40'}`}
              />
            ))}
          </div>
          <button
            type="button"
            onClick={() => step(1)}
            className="flex h-10 w-10 items-center justify-center rounded-full border border-white/30 transition hover:bg-white/10"
            aria-label={tx('التالي', 'Next')}
          >
            <Next size={18} />
          </button>
        </div>
      </div>
    </section>
  );
}
