import { Sparkles } from 'lucide-react';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';

export default function AnnouncementBar() {
  const { settings } = useCatalog();
  const { tx } = usePreferences();
  const text = tx(settings.announcement_ar, settings.announcement_en);
  if (!text) return null;

  return (
    <div className="overflow-hidden bg-accent text-white">
      <div className="flex w-max animate-[marquee_28s_linear_infinite] items-center gap-12 whitespace-nowrap py-2 text-xs font-semibold tracking-wide sm:text-sm">
        {[0, 1].map((copy) => (
          <span key={copy} className="flex items-center gap-3">
            <Sparkles size={14} className="text-gold" />
            {text}
          </span>
        ))}
      </div>
    </div>
  );
}
