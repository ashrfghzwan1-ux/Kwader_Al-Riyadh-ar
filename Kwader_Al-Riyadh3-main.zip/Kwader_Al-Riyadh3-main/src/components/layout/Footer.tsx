import { MapPin, Phone } from 'lucide-react';
import AppLink from '@/components/common/AppLink';
import Logo from '@/components/common/Logo';
import { BRAND } from '@/lib/constants';
import { usePreferences } from '@/context/PreferencesContext';
import { useCatalog } from '@/context/CatalogContext';

export default function Footer() {
  const { tx } = usePreferences();
  const { settings } = useCatalog();
  const hours = [
    { label: tx('السبت - الخميس', 'Sat - Thu'), value: tx(settings.hours_main_ar, settings.hours_main_en) },
    { label: tx('الجمعة', 'Friday'), value: tx(settings.hours_friday_ar, settings.hours_friday_en) },
  ];

  return (
    <footer className="mt-24 border-t border-line bg-surface">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-3">
        <div className="space-y-4">
          <Logo />
          <p className="max-w-sm text-sm leading-relaxed text-muted">
            {tx(
              'معسلات وشيش وسحبات إلكترونية وإكسسوارات فاخرة، مختارة بعناية لعشاق الجلسات الراقية في الرياض.',
              'Premium molasses, hookahs, disposable vapes and accessories, selected for lovers of refined sessions in Riyadh.',
            )}
          </p>
        </div>

        <div className="space-y-4">
          <h3 className="eyebrow">{tx('روابط سريعة', 'Quick links')}</h3>
          <ul className="grid grid-cols-2 gap-2 text-sm">
            {[
              ['/catalog', tx('المتجر', 'Shop')],
              ['/offers', tx('عروض اليوم', "Today's Offers")],
              ['/about', tx('من نحن', 'About')],
              ['/services', tx('الخدمات', 'Services')],
              ['/gallery', tx('معرض الصور', 'Gallery')],
              ['/contact', tx('تواصل معنا', 'Contact')],
            ].map(([to, label]) => (
              <li key={to}>
                <AppLink to={to} className="text-muted transition hover:text-gold-text">
                  {label}
                </AppLink>
              </li>
            ))}
          </ul>
        </div>

        <div className="space-y-4 text-sm">
          <h3 className="eyebrow">{tx('تواصل', 'Contact')}</h3>
          <a href={`tel:${BRAND.phoneTel}`} className="flex items-center gap-2 text-ink hover:text-gold-text">
            <Phone size={16} className="text-gold-text" /> {BRAND.phoneDisplay}
          </a>
          <p className="flex items-start gap-2 text-muted">
            <MapPin size={16} className="mt-0.5 shrink-0 text-gold-text" />
            {tx(settings.address_ar, settings.address_en)}
          </p>
          {hours.map((row) => (
            <p key={row.label} className="text-muted">
              <span className="font-semibold text-ink">{row.label}:</span> {row.value}
            </p>
          ))}
        </div>
      </div>
      <div className="border-t border-line py-5 text-center text-xs text-muted">
        © {new Date().getFullYear()} {tx(BRAND.nameAr, BRAND.nameEn)}
      </div>
    </footer>
  );
}
