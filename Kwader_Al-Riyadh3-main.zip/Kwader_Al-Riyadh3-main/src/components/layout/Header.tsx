import { useEffect, useState } from 'react';
import { Menu, Minus, Plus, ShoppingBag } from 'lucide-react';
import AppLink from '@/components/common/AppLink';
import Logo from '@/components/common/Logo';
import { useCart } from '@/context/CartContext';
import { usePreferences } from '@/context/PreferencesContext';
import { useNavigation } from '@/context/NavigationContext';
import ThemeLangControls from '@/components/layout/ThemeLangControls';

interface HeaderProps {
  onOpenSidebar: () => void;
}

const NAV_LINKS = [
  { to: '/', ar: 'الرئيسية', en: 'Home' },
  { to: '/catalog', ar: 'المتجر', en: 'Shop' },
  { to: '/offers', ar: 'عروض اليوم', en: "Today's Offers" },
  { to: '/contact', ar: 'تواصل معنا', en: 'Contact' },
];

export default function Header({ onOpenSidebar }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const { tx, canIncreaseFont, canDecreaseFont, increaseFont, decreaseFont } = usePreferences();
  const { count, openCart } = useCart();
  const { path } = useNavigation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-40 border-b transition-all duration-500 ${
        scrolled ? 'border-line bg-bg/90 shadow-lg backdrop-blur-xl' : 'border-transparent bg-bg'
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:gap-4 sm:px-6">
        <button type="button" onClick={onOpenSidebar} className="icon-btn" aria-label={tx('القائمة', 'Menu')}>
          <Menu size={18} />
        </button>

        <AppLink to="/" className="min-w-0 flex-1 lg:flex-none">
          <Logo />
        </AppLink>

        <nav className="mx-auto hidden items-center gap-7 lg:flex">
          {NAV_LINKS.map((link) => {
            const active = path === link.to;
            return (
              <AppLink
                key={link.to}
                to={link.to}
                className={`relative text-sm font-semibold transition hover:text-gold-text ${
                  active ? 'text-gold-text' : 'text-ink'
                }`}
              >
                {tx(link.ar, link.en)}
                <span
                  className={`absolute -bottom-1.5 start-0 h-0.5 rounded-full bg-gold transition-all duration-300 ${
                    active ? 'w-full' : 'w-0'
                  }`}
                />
              </AppLink>
            );
          })}
        </nav>

        <div className="ms-auto flex items-center gap-2">
          <div className="hidden items-center gap-1 rounded-full border border-line bg-surface p-1 md:flex">
            <button
              type="button"
              onClick={decreaseFont}
              disabled={!canDecreaseFont}
              className="flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold transition hover:text-gold-text disabled:opacity-40"
              aria-label={tx('تصغير الخط', 'Decrease text size')}
            >
              <Minus size={14} />
              <span className="sr-only">A</span>
            </button>
            <span className="px-1 text-xs font-bold text-muted">A</span>
            <button
              type="button"
              onClick={increaseFont}
              disabled={!canIncreaseFont}
              className="flex h-8 w-8 items-center justify-center rounded-full text-sm font-bold transition hover:text-gold-text disabled:opacity-40"
              aria-label={tx('تكبير الخط', 'Increase text size')}
            >
              <Plus size={14} />
            </button>
          </div>
          <ThemeLangControls className="hidden md:flex" />

          <button
            type="button"
            onClick={openCart}
            className="relative icon-btn"
            aria-label={tx('السلة', 'Cart')}
          >
            <ShoppingBag size={18} />
            {count > 0 && (
              <span className="absolute -end-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1 text-[0.65rem] font-bold text-black shadow-gold">
                {count}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
