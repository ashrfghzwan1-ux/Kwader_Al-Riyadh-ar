import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronDown, MessageCircle, Phone, X } from 'lucide-react';
import AppLink from '@/components/common/AppLink';
import Logo from '@/components/common/Logo';
import SidebarFilters from '@/components/layout/SidebarFilters';
import ThemeLangControls from '@/components/layout/ThemeLangControls';
import { useCatalog } from '@/context/CatalogContext';
import { useNavigation } from '@/context/NavigationContext';
import { usePreferences } from '@/context/PreferencesContext';
import { BRAND } from '@/lib/constants';
import { buildWhatsappUrl } from '@/lib/whatsapp';

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

const NAV_LINKS = [
  { to: '/', ar: 'الرئيسية', en: 'Home' },
  { to: '/about', ar: 'من نحن', en: 'About us' },
  { to: '/services', ar: 'الخدمات', en: 'Services' },
  { to: '/flavors', ar: 'خلطات النكهات', en: 'Flavor blends' },
  { to: '/gallery', ar: 'معرض الصور', en: 'Gallery' },
  { to: '/contact', ar: 'تواصل معنا', en: 'Contact' },
  { to: '/offers', ar: 'عروض اليوم', en: "Today's offers" },
];

export default function Sidebar({ open, onClose }: SidebarProps) {
  const { categories, products, updateFilters, filters } = useCatalog();
  const { navigate } = useNavigation();
  const { tx, lang } = usePreferences();
  const [expanded, setExpanded] = useState<string | null>(null);

  const openCategory = (categoryId: string) => {
    updateFilters({ categoryId, search: '' });
    navigate('/catalog');
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[60]">
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.aside
            role="dialog"
            aria-modal="true"
            aria-label={tx('القائمة الرئيسية', 'Main menu')}
            className="absolute inset-y-0 right-0 flex w-[min(92vw,400px)] flex-col border-s border-line bg-surface shadow-lift"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
          >
            <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-4">
              <Logo compact />
              <button type="button" onClick={onClose} className="icon-btn" aria-label={tx('إغلاق', 'Close')}>
                <X size={18} />
              </button>
            </div>

            <div className="flex-1 space-y-8 overflow-y-auto px-5 py-6">
              <section className="flex flex-wrap items-center gap-3">
                <ThemeLangControls />
                <FontControls />
              </section>

              <section className="space-y-3">
                <h3 className="eyebrow">{tx('الأقسام', 'Categories')}</h3>
                <ul className="space-y-2">
                  {categories.map((category) => {
                    const isOpen = expanded === category.id;
                    const items = products.filter((p) => p.category_id === category.id);
                    return (
                      <li key={category.id} className="overflow-hidden rounded-xl border border-line bg-bg">
                        <button
                          type="button"
                          onClick={() => setExpanded(isOpen ? null : category.id)}
                          className="flex w-full items-center justify-between gap-3 px-4 py-3 text-start text-sm font-semibold transition hover:text-gold-text"
                          aria-expanded={isOpen}
                        >
                          <span>{lang === 'ar' ? category.name_ar : category.name_en}</span>
                          <span className="flex items-center gap-2 text-xs text-muted">
                            {items.length}
                            <ChevronDown
                              size={16}
                              className={`transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
                            />
                          </span>
                        </button>
                        <AnimatePresence initial={false}>
                          {isOpen && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.25 }}
                              className="overflow-hidden"
                            >
                              <div className="space-y-1 border-t border-line px-2 py-2">
                                {items.slice(0, 4).map((product) => (
                                  <AppLink
                                    key={product.id}
                                    to={`/product/${product.id}`}
                                    onNavigate={onClose}
                                    className="block truncate rounded-lg px-3 py-2 text-xs text-muted transition hover:bg-surface-2 hover:text-ink"
                                  >
                                    {lang === 'ar' ? product.name_ar : product.name_en}
                                  </AppLink>
                                ))}
                                <button
                                  type="button"
                                  onClick={() => openCategory(category.id)}
                                  className="w-full rounded-lg bg-accent px-3 py-2 text-xs font-semibold text-white transition hover:bg-accent-strong"
                                >
                                  {tx('عرض كل المنتجات', 'View all products')}
                                </button>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </li>
                    );
                  })}
                </ul>
              </section>

              <SidebarFilters
                filters={filters}
                onChange={updateFilters}
                onApply={() => navigate('/catalog')}
              />

              <section className="space-y-2">
                <h3 className="eyebrow">{tx('الصفحات', 'Pages')}</h3>
                <ul className="grid gap-1">
                  {NAV_LINKS.map((link) => (
                    <li key={link.to}>
                      <AppLink
                        to={link.to}
                        onNavigate={onClose}
                        className="block rounded-lg px-3 py-2.5 text-sm font-semibold transition hover:bg-surface-2 hover:text-gold-text"
                      >
                        {tx(link.ar, link.en)}
                      </AppLink>
                    </li>
                  ))}
                </ul>
              </section>
            </div>

            <div className="grid grid-cols-2 gap-3 border-t border-line p-5">
              <a href={`tel:${BRAND.phoneTel}`} className="btn-outline">
                <Phone size={16} />
                {tx('اتصال', 'Call')}
              </a>
              <a
                href={buildWhatsappUrl(tx('مرحباً، أود الاستفسار عن منتجاتكم', 'Hello, I would like to ask about your products'))}
                target="_blank"
                rel="noreferrer"
                className="btn-gold"
              >
                <MessageCircle size={16} />
                {tx('واتساب', 'WhatsApp')}
              </a>
              <p className="col-span-2 text-center text-xs text-muted" dir="ltr">
                {BRAND.phoneDisplay}
              </p>
            </div>
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}

function FontControls() {
  const { canIncreaseFont, canDecreaseFont, increaseFont, decreaseFont, tx } = usePreferences();
  return (
    <div className="flex items-center gap-1 rounded-full border border-line bg-bg p-1">
      <button
        type="button"
        onClick={decreaseFont}
        disabled={!canDecreaseFont}
        className="h-8 w-9 rounded-full text-xs font-bold transition hover:text-gold-text disabled:opacity-40"
        aria-label={tx('تصغير الخط', 'Decrease text size')}
      >
        -A
      </button>
      <button
        type="button"
        onClick={increaseFont}
        disabled={!canIncreaseFont}
        className="h-8 w-9 rounded-full text-sm font-bold transition hover:text-gold-text disabled:opacity-40"
        aria-label={tx('تكبير الخط', 'Increase text size')}
      >
        +A
      </button>
    </div>
  );
}
