import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { formatPrice } from '@/lib/format';
import { NICOTINE_LEVELS } from '@/lib/constants';
import type { CatalogFilters } from '@/lib/filterProducts';
import type { FlavorProfile } from '@/types/store';

const FLAVOR_CHIPS: { value: FlavorProfile; ar: string; en: string }[] = [
  { value: 'fruit', ar: 'فواكه', en: 'Fruits' },
  { value: 'mint', ar: 'نعناع', en: 'Mint' },
  { value: 'citrus', ar: 'حوامض', en: 'Citrus' },
  { value: 'dessert', ar: 'حلا', en: 'Dessert' },
];

interface SidebarFiltersProps {
  filters: CatalogFilters;
  onChange: (patch: Partial<CatalogFilters>) => void;
  onApply: () => void;
}

function toggle<T>(list: T[], value: T): T[] {
  return list.includes(value) ? list.filter((item) => item !== value) : [...list, value];
}

export default function SidebarFilters({ filters, onChange, onApply }: SidebarFiltersProps) {
  const { tx, lang } = usePreferences();
  const { priceBounds, resetFilters } = useCatalog();

  const min = filters.priceRange?.min ?? priceBounds.min;
  const max = filters.priceRange?.max ?? priceBounds.max;
  const span = Math.max(priceBounds.max - priceBounds.min, 1);
  const leftPct = ((min - priceBounds.min) / span) * 100;
  const rightPct = ((max - priceBounds.min) / span) * 100;

  const updateRange = (nextMin: number, nextMax: number) => {
    onChange({ priceRange: { min: Math.min(nextMin, nextMax), max: Math.max(nextMin, nextMax) } });
    onApply();
  };

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="eyebrow">{tx('تصفية المنتجات', 'Filter products')}</h3>
        <button type="button" onClick={resetFilters} className="text-xs font-semibold text-muted hover:text-gold-text">
          {tx('مسح الكل', 'Clear all')}
        </button>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm">
          <span className="font-semibold">{tx('نطاق السعر', 'Price range')}</span>
          <span className="text-xs text-muted">
            {formatPrice(min, lang)} - {formatPrice(max, lang)}
          </span>
        </div>
        <div className="relative h-6">
          <div className="absolute inset-x-0 top-1/2 h-1.5 -translate-y-1/2 rounded-full bg-surface-2" />
          <div
            className="absolute top-1/2 h-1.5 -translate-y-1/2 rounded-full bg-gold"
            style={{ insetInlineStart: `${leftPct}%`, insetInlineEnd: `${100 - rightPct}%` }}
          />
          <input
            type="range"
            aria-label={tx('أقل سعر', 'Minimum price')}
            className="range-luxe"
            min={priceBounds.min}
            max={priceBounds.max}
            value={min}
            onChange={(e) => updateRange(Number(e.target.value), max)}
          />
          <input
            type="range"
            aria-label={tx('أعلى سعر', 'Maximum price')}
            className="range-luxe"
            min={priceBounds.min}
            max={priceBounds.max}
            value={max}
            onChange={(e) => updateRange(min, Number(e.target.value))}
          />
        </div>
      </div>

      <div className="space-y-3">
        <span className="text-sm font-semibold">{tx('نكهات', 'Flavor profile')}</span>
        <div className="flex flex-wrap gap-2">
          {FLAVOR_CHIPS.map((chip) => {
            const active = filters.flavors.includes(chip.value);
            return (
              <button
                key={chip.value}
                type="button"
                aria-pressed={active}
                onClick={() => {
                  onChange({ flavors: toggle(filters.flavors, chip.value) });
                  onApply();
                }}
                className={`rounded-full border px-4 py-1.5 text-xs font-semibold transition ${
                  active
                    ? 'border-gold bg-gold text-black'
                    : 'border-line bg-bg text-ink hover:border-gold hover:text-gold-text'
                }`}
              >
                {tx(chip.ar, chip.en)}
              </button>
            );
          })}
        </div>
      </div>

      <div className="space-y-3">
        <span className="text-sm font-semibold">{tx('قوة النيكوتين', 'Nicotine strength')}</span>
        <div className="flex flex-wrap gap-2">
          {NICOTINE_LEVELS.map((level) => {
            const active = filters.nicotine.includes(level);
            return (
              <button
                key={level}
                type="button"
                aria-pressed={active}
                onClick={() => {
                  onChange({ nicotine: toggle(filters.nicotine, level) });
                  onApply();
                }}
                className={`min-w-14 rounded-lg border px-3 py-1.5 text-xs font-bold transition ${
                  active
                    ? 'border-emerald bg-emerald text-white'
                    : 'border-line bg-bg text-ink hover:border-emerald hover:text-emerald'
                }`}
              >
                {level}
              </button>
            );
          })}
        </div>
      </div>

      <label className="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-line bg-bg px-4 py-3">
        <span className="text-sm font-semibold">{tx('المتوفر فقط', 'In stock only')}</span>
        <input
          type="checkbox"
          className="peer sr-only"
          checked={filters.inStockOnly}
          onChange={(e) => {
            onChange({ inStockOnly: e.target.checked });
            onApply();
          }}
        />
        <span
          className={`relative h-6 w-11 rounded-full transition-colors ${
            filters.inStockOnly ? 'bg-emerald' : 'bg-surface-2 ring-1 ring-line'
          }`}
        >
          <span
            className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
              filters.inStockOnly ? 'start-[22px]' : 'start-0.5'
            }`}
          />
        </span>
      </label>
    </section>
  );
}
