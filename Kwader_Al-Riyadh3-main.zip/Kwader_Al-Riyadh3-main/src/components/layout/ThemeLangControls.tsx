import { Languages, Moon, Sun } from 'lucide-react';
import { usePreferences } from '@/context/PreferencesContext';

interface ThemeLangControlsProps {
  className?: string;
}

export default function ThemeLangControls({ className = '' }: ThemeLangControlsProps) {
  const { theme, lang, toggleTheme, toggleLang, tx } = usePreferences();
  const isDark = theme === 'dark';

  return (
    <div className={`items-center gap-2 ${className}`}>
      <button
        type="button"
        onClick={toggleTheme}
        className="icon-btn"
        aria-label={tx('تبديل الوضع الليلي والنهاري', 'Toggle dark and light mode')}
        title={tx('الوضع', 'Theme')}
      >
        {isDark ? <Sun size={18} className="text-gold-text" /> : <Moon size={18} className="text-accent" />}
      </button>
      <button
        type="button"
        onClick={toggleLang}
        className="icon-btn px-3 w-auto gap-1.5 text-xs font-bold"
        aria-label={tx('تغيير اللغة إلى الإنجليزية', 'Switch language to Arabic')}
      >
        <Languages size={15} />
        {lang === 'ar' ? 'EN' : 'AR'}
      </button>
    </div>
  );
}
