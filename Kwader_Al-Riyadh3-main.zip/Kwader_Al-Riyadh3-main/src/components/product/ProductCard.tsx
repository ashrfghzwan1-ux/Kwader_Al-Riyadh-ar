import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import AppLink from '@/components/common/AppLink';
import { useCart } from '@/context/CartContext';
import { usePreferences } from '@/context/PreferencesContext';
import { discountPercent, formatPrice } from '@/lib/format';
import type { Product } from '@/types/store';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { tx, lang } = usePreferences();
  const { addItem } = useCart();
  const soldOut = product.stock <= 0;
  const off = discountPercent(product.price, product.compare_at_price);
  const name = lang === 'ar' ? product.name_ar : product.name_en;

  const handleAdd = () => {
    addItem(product, {
      flavor: product.flavor_options[0] ?? null,
      nicotine: product.nicotine_levels[0] ?? null,
    });
  };

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="group flex flex-col overflow-hidden rounded-2xl border border-line bg-surface shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-gold/60 hover:shadow-lift"
    >
      <AppLink to={`/product/${product.id}`} className="relative block aspect-square overflow-hidden bg-surface-2">
        <img
          src={product.image_url}
          alt={name}
          loading="lazy"
          className={`h-full w-full object-cover transition duration-700 group-hover:scale-105 ${
            soldOut ? 'grayscale' : ''
          }`}
        />
        <div className="absolute start-3 top-3 flex flex-col gap-1.5">
          {off > 0 && !soldOut && (
            <span className="rounded-full bg-accent px-2.5 py-1 text-[0.7rem] font-bold text-white">-{off}%</span>
          )}
          {soldOut && (
            <span className="rounded-full bg-black/80 px-2.5 py-1 text-[0.7rem] font-bold text-white">
              {tx('نفدت الكمية', 'Sold out')}
            </span>
          )}
        </div>
        {!soldOut && product.stock <= 5 && (
          <span className="absolute end-3 top-3 rounded-full bg-gold px-2.5 py-1 text-[0.7rem] font-bold text-black">
            {tx(`باقي ${product.stock}`, `${product.stock} left`)}
          </span>
        )}
      </AppLink>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <AppLink to={`/product/${product.id}`} className="line-clamp-2 min-h-[2.75rem] text-sm font-semibold leading-snug hover:text-gold-text">
          {name}
        </AppLink>

        <div className="mt-auto flex items-end justify-between gap-2">
          <div className="flex flex-col">
            {product.compare_at_price && product.compare_at_price > product.price && (
              <span className="text-xs text-muted line-through">{formatPrice(product.compare_at_price, lang)}</span>
            )}
            <span className="text-base font-bold text-gold-text">{formatPrice(product.price, lang)}</span>
          </div>
          <button
            type="button"
            onClick={handleAdd}
            disabled={soldOut}
            className="btn-primary px-4 py-2 text-xs sm:text-sm"
          >
            <Plus size={15} />
            {soldOut ? tx('نفدت الكمية', 'Sold out') : tx('إضافة للسلة', 'Add to cart')}
          </button>
        </div>
      </div>
    </motion.article>
  );
}
