import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useCatalog } from '@/context/CatalogContext';
import { fetchPromoPercent, placeOrder } from '@/lib/storeApi';
import type { CartSelection, Order, Product } from '@/types/store';

const STORAGE_KEY = 'kwader-cart';

export interface CartLine extends CartSelection {
  productId: string;
  qty: number;
}

export interface CartItemView {
  key: string;
  line: CartLine;
  product: Product;
}

interface AppliedCoupon {
  code: string;
  percent: number;
}

interface CartValue {
  isOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  items: CartItemView[];
  count: number;
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  freeShippingRemaining: number;
  coupon: AppliedCoupon | null;
  applyCoupon: (code: string) => Promise<void>;
  removeCoupon: () => void;
  addItem: (product: Product, selection: CartSelection) => void;
  changeQty: (key: string, delta: number) => void;
  changeOptions: (key: string, selection: CartSelection) => void;
  removeItem: (key: string) => void;
  checkout: () => Promise<Order>;
}

const CartContext = createContext<CartValue | null>(null);

export function lineKey(line: Pick<CartLine, 'productId' | 'flavor' | 'nicotine'>): string {
  return [line.productId, line.flavor?.en ?? '', line.nicotine ?? ''].join('|');
}

function loadLines(): CartLine[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as CartLine[]) : [];
  } catch {
    return [];
  }
}

function mergeLines(lines: CartLine[], productsById: Map<string, Product>): CartLine[] {
  const merged: CartLine[] = [];
  for (const line of lines) {
    const index = merged.findIndex((existing) => lineKey(existing) === lineKey(line));
    if (index === -1) {
      merged.push(line);
      continue;
    }
    const stock = productsById.get(line.productId)?.stock ?? 0;
    merged[index] = { ...merged[index], qty: Math.min(merged[index].qty + line.qty, stock) };
  }
  return merged.filter((line) => line.qty > 0);
}

export function CartProvider({ children }: { children: ReactNode }) {
  const { products, freeShippingThreshold, shippingFee, reload } = useCatalog();
  const [lines, setLines] = useState<CartLine[]>(loadLines);
  const [isOpen, setIsOpen] = useState(false);
  const [coupon, setCoupon] = useState<AppliedCoupon | null>(null);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
  }, [lines]);

  const productsById = useMemo(() => new Map(products.map((p) => [p.id, p])), [products]);

  const items = useMemo<CartItemView[]>(
    () =>
      lines.flatMap((line) => {
        const product = productsById.get(line.productId);
        return product ? [{ key: lineKey(line), line, product }] : [];
      }),
    [lines, productsById],
  );

  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.line.qty, 0);
  const discount = coupon ? Math.round(subtotal * coupon.percent) / 100 : 0;
  const discounted = subtotal - discount;
  const shipping = items.length > 0 && discounted < freeShippingThreshold ? shippingFee : 0;
  const total = discounted + shipping;
  const count = items.reduce((sum, item) => sum + item.line.qty, 0);
  const freeShippingRemaining = Math.max(freeShippingThreshold - discounted, 0);

  const openCart = useCallback(() => setIsOpen(true), []);
  const closeCart = useCallback(() => setIsOpen(false), []);

  const addItem = useCallback(
    (product: Product, selection: CartSelection) => {
      if (product.stock <= 0) return;
      setLines((current) => {
        const candidate: CartLine = { productId: product.id, ...selection, qty: 1 };
        const key = lineKey(candidate);
        const existing = current.find((line) => lineKey(line) === key);
        if (!existing) return [...current, candidate];
        return current.map((line) =>
          lineKey(line) === key ? { ...line, qty: Math.min(line.qty + 1, product.stock) } : line,
        );
      });
      setIsOpen(true);
    },
    [],
  );

  const changeQty = useCallback(
    (key: string, delta: number) => {
      setLines((current) => {
        const updated = current.map((line) => {
          if (lineKey(line) !== key) return line;
          const stock = productsById.get(line.productId)?.stock ?? 0;
          return { ...line, qty: Math.min(Math.max(line.qty + delta, 0), stock) };
        });
        return updated.filter((line) => line.qty > 0);
      });
    },
    [productsById],
  );

  const changeOptions = useCallback(
    (key: string, selection: CartSelection) => {
      setLines((current) => {
        const updated = current.map((line) =>
          lineKey(line) === key ? { ...line, flavor: selection.flavor, nicotine: selection.nicotine } : line,
        );
        return mergeLines(updated, productsById);
      });
    },
    [productsById],
  );

  const removeItem = useCallback((key: string) => {
    setLines((current) => current.filter((line) => lineKey(line) !== key));
  }, []);

  const applyCoupon = useCallback(async (code: string) => {
    const normalized = code.trim().toUpperCase();
    const percent = await fetchPromoPercent(normalized);
    if (percent === null) throw new Error('INVALID_COUPON');
    setCoupon({ code: normalized, percent });
  }, []);

  const removeCoupon = useCallback(() => setCoupon(null), []);

  const checkout = useCallback(async () => {
    const order = await placeOrder(
      items.map((item) => ({
        product_id: item.line.productId,
        qty: item.line.qty,
        flavor: item.line.flavor,
        nicotine: item.line.nicotine,
      })),
      coupon?.code ?? null,
    );
    setLines([]);
    setCoupon(null);
    await reload();
    return order;
  }, [items, coupon, reload]);

  const value = useMemo<CartValue>(
    () => ({
      isOpen,
      openCart,
      closeCart,
      items,
      count,
      subtotal,
      discount,
      shipping,
      total,
      freeShippingRemaining,
      coupon,
      applyCoupon,
      removeCoupon,
      addItem,
      changeQty,
      changeOptions,
      removeItem,
      checkout,
    }),
    [
      isOpen, openCart, closeCart, items, count, subtotal, discount, shipping, total,
      freeShippingRemaining, coupon, applyCoupon, removeCoupon, addItem, changeQty,
      changeOptions, removeItem, checkout,
    ],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartValue {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within CartProvider');
  return context;
}
