import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { DEFAULT_FILTERS, type CatalogFilters } from '@/lib/filterProducts';
import { fetchCatalog, fetchSettings } from '@/lib/storeApi';
import type { Category, Product, SiteSettings } from '@/types/store';

type LoadStatus = 'loading' | 'ready' | 'error';

interface CatalogValue {
  categories: Category[];
  products: Product[];
  settings: SiteSettings;
  status: LoadStatus;
  error: string | null;
  reload: () => Promise<void>;
  priceBounds: { min: number; max: number };
  filters: CatalogFilters;
  updateFilters: (patch: Partial<CatalogFilters>) => void;
  resetFilters: () => void;
  freeShippingThreshold: number;
  shippingFee: number;
}

const CatalogContext = createContext<CatalogValue | null>(null);

export function CatalogProvider({ children }: { children: ReactNode }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [settings, setSettings] = useState<SiteSettings>({});
  const [status, setStatus] = useState<LoadStatus>('loading');
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState<CatalogFilters>(DEFAULT_FILTERS);

  const reload = useCallback(async () => {
    setError(null);
    try {
      const [catalog, siteSettings] = await Promise.all([fetchCatalog(), fetchSettings()]);
      setCategories(catalog.categories);
      setProducts(catalog.products);
      setSettings(siteSettings);
      setStatus('ready');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'UNKNOWN_ERROR');
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const priceBounds = useMemo(() => {
    if (products.length === 0) return { min: 0, max: 0 };
    const prices = products.map((p) => p.price);
    return { min: Math.floor(Math.min(...prices)), max: Math.ceil(Math.max(...prices)) };
  }, [products]);

  const updateFilters = useCallback((patch: Partial<CatalogFilters>) => {
    setFilters((current) => ({ ...current, ...patch }));
  }, []);

  const resetFilters = useCallback(() => setFilters(DEFAULT_FILTERS), []);

  const value = useMemo<CatalogValue>(
    () => ({
      categories,
      products,
      settings,
      status,
      error,
      reload,
      priceBounds,
      filters,
      updateFilters,
      resetFilters,
      freeShippingThreshold: Number(settings.free_shipping_threshold) || 0,
      shippingFee: Number(settings.shipping_fee) || 0,
    }),
    [categories, products, settings, status, error, reload, priceBounds, filters, updateFilters, resetFilters],
  );

  return <CatalogContext.Provider value={value}>{children}</CatalogContext.Provider>;
}

export function useCatalog(): CatalogValue {
  const context = useContext(CatalogContext);
  if (!context) throw new Error('useCatalog must be used within CatalogProvider');
  return context;
}
