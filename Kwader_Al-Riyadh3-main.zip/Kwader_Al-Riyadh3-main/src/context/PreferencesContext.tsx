import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Lang, Theme } from '@/types/store';

const STORAGE_KEY = 'kwader-preferences';
const FONT_STEPS = [90, 100, 110, 125] as const;

interface StoredPreferences {
  theme: Theme;
  lang: Lang;
  fontStep: number;
}

const DEFAULT_PREFERENCES: StoredPreferences = { theme: 'dark', lang: 'ar', fontStep: 1 };

function loadPreferences(): StoredPreferences {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_PREFERENCES;
    const parsed = JSON.parse(raw) as Partial<StoredPreferences>;
    const fontStep = Number.isInteger(parsed.fontStep) ? (parsed.fontStep as number) : 1;
    return {
      theme: parsed.theme === 'light' ? 'light' : 'dark',
      lang: parsed.lang === 'en' ? 'en' : 'ar',
      fontStep: Math.min(Math.max(fontStep, 0), FONT_STEPS.length - 1),
    };
  } catch {
    return DEFAULT_PREFERENCES;
  }
}

interface PreferencesValue {
  theme: Theme;
  lang: Lang;
  isRtl: boolean;
  fontPercent: number;
  canIncreaseFont: boolean;
  canDecreaseFont: boolean;
  toggleTheme: () => void;
  toggleLang: () => void;
  increaseFont: () => void;
  decreaseFont: () => void;
  tx: <T>(ar: T, en: T) => T;
}

const PreferencesContext = createContext<PreferencesValue | null>(null);

export function PreferencesProvider({ children }: { children: ReactNode }) {
  const [prefs, setPrefs] = useState<StoredPreferences>(loadPreferences);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    const root = document.documentElement;
    root.classList.toggle('dark', prefs.theme === 'dark');
    root.setAttribute('dir', prefs.lang === 'ar' ? 'rtl' : 'ltr');
    root.setAttribute('lang', prefs.lang);
    root.style.fontSize = `${FONT_STEPS[prefs.fontStep]}%`;
  }, [prefs]);

  const toggleTheme = useCallback(
    () => setPrefs((p) => ({ ...p, theme: p.theme === 'dark' ? 'light' : 'dark' })),
    [],
  );
  const toggleLang = useCallback(() => setPrefs((p) => ({ ...p, lang: p.lang === 'ar' ? 'en' : 'ar' })), []);
  const increaseFont = useCallback(
    () => setPrefs((p) => ({ ...p, fontStep: Math.min(p.fontStep + 1, FONT_STEPS.length - 1) })),
    [],
  );
  const decreaseFont = useCallback(() => setPrefs((p) => ({ ...p, fontStep: Math.max(p.fontStep - 1, 0) })), []);

  const value = useMemo<PreferencesValue>(
    () => ({
      theme: prefs.theme,
      lang: prefs.lang,
      isRtl: prefs.lang === 'ar',
      fontPercent: FONT_STEPS[prefs.fontStep],
      canIncreaseFont: prefs.fontStep < FONT_STEPS.length - 1,
      canDecreaseFont: prefs.fontStep > 0,
      toggleTheme,
      toggleLang,
      increaseFont,
      decreaseFont,
      tx: <T,>(ar: T, en: T) => (prefs.lang === 'ar' ? ar : en),
    }),
    [prefs, toggleTheme, toggleLang, increaseFont, decreaseFont],
  );

  return <PreferencesContext.Provider value={value}>{children}</PreferencesContext.Provider>;
}

export function usePreferences(): PreferencesValue {
  const context = useContext(PreferencesContext);
  if (!context) throw new Error('usePreferences must be used within PreferencesProvider');
  return context;
}
