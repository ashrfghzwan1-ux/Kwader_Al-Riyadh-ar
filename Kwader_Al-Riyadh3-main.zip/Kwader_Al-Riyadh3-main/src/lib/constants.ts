export const BRAND = {
  nameAr: 'كوادر الرياض للشيش والمعسلات',
  nameEn: 'Kwader Al-Riyadh for Shisha & Molasses',
  phoneDisplay: '+966 56 094 0585',
  phoneTel: '+966560940585',
  whatsappNumber: '966560940585',
  addressAr: 'غرناطة، المزاحمية 19672، المملكة العربية السعودية',
  addressEn: 'Granada, Al-Muzahimiyah 19672, Kingdom of Saudi Arabia',
  mapEmbedUrl: 'https://maps.google.com/maps?q=Al-Muzahimiyah%2019672%20Saudi%20Arabia&t=&z=14&ie=UTF8&iwloc=&output=embed',
  mapDirectionsUrl: 'https://www.google.com/maps/dir/?api=1&destination=Al-Muzahimiyah+19672+Saudi+Arabia',
} as const;

export const ADMIN_PIN = '1234';

export const NICOTINE_LEVELS = ['0mg', '3mg', '20mg', '50mg'] as const;
