import { discountPercent } from '@/lib/format';
import type { FlavorProfile, Product } from '@/types/store';

export type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'discount';

export interface CatalogFilters {
  search: string;
  categoryId: string | null;
  priceRange: { min: number; max: number } | null;
  flavors: FlavorProfile[];
  nicotine: string[];
  inStockOnly: boolean;
  sort: SortOption;
}

export const DEFAULT_FILTERS: CatalogFilters = {
  search: '',
  categoryId: null,
  priceRange: null,
  flavors: [],
  nicotine: [],
  inStockOnly: false,
  sort: 'featured',
};

export function filterProducts(products: Product[], filters: CatalogFilters): Product[] {
  const query = filters.search.trim().toLowerCase();
  const result = products.filter((product) => {
    if (filters.categoryId && product.category_id !== filters.categoryId) return false;
    if (filters.priceRange) {
      if (product.price < filters.priceRange.min || product.price > filters.priceRange.max) return false;
    }
    if (filters.flavors.length && !filters.flavors.includes(product.flavor_profile)) return false;
    if (filters.nicotine.length && !filters.nicotine.some((level) => product.nicotine_levels.includes(level))) {
      return false;
    }
    if (filters.inStockOnly && product.stock <= 0) return false;
    if (query) {
      const haystack = `${product.name_ar} ${product.name_en}`.toLowerCase();
      if (!haystack.includes(query)) return false;
    }
    return true;
  });

  switch (filters.sort) {
    case 'price-asc':
      return [...result].sort((a, b) => a.price - b.price);
    case 'price-desc':
      return [...result].sort((a, b) => b.price - a.price);
    case 'discount':
      return [...result].sort(
        (a, b) => discountPercent(b.price, b.compare_at_price) - discountPercent(a.price, a.compare_at_price),
      );
    default:
      return result;
  }
}
