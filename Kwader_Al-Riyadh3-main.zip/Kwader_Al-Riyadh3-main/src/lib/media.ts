export function photoUrl(id: number): string {
  return `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&h=650&w=940`;
}

export const CATEGORY_PHOTOS: Record<string, string> = {
  'premium-molasses': photoUrl(16624534),
  'e-vapes': photoUrl(33298190),
  'flavors-salts': photoUrl(31251024),
  hookahs: photoUrl(774378),
  'devices-pods': photoUrl(40447754),
  'charcoal-accessories': photoUrl(8863347),
  'papers-accessories': photoUrl(13564526),
};

export const HERO_PHOTO = photoUrl(774378);

export const GALLERY_PHOTOS = [
  { url: photoUrl(774378), ar: 'شيشة نحاسية فاخرة', en: 'Luxury brass hookah' },
  { url: photoUrl(8863347), ar: 'فحم عالي الحرارة', en: 'High-heat charcoal' },
  { url: photoUrl(33298190), ar: 'أجهزة السحب الإلكترونية', en: 'Electronic vape devices' },
  { url: photoUrl(40447754), ar: 'أجهزة وبودات حديثة', en: 'Modern devices and pods' },
  { url: photoUrl(16624534), ar: 'تفاصيل التبغ الفاخر', en: 'Premium tobacco details' },
  { url: photoUrl(31251024), ar: 'سوائل ونكهات مركزة', en: 'Concentrated e-liquids' },
  { url: photoUrl(10005648), ar: 'تجهيزات الجلسة', en: 'Session essentials' },
  { url: photoUrl(13564526), ar: 'ورق لف وإكسسوارات', en: 'Papers and accessories' },
  { url: photoUrl(34776659), ar: 'نكهات بتركيبة خاصة', en: 'Signature flavor blends' },
];
