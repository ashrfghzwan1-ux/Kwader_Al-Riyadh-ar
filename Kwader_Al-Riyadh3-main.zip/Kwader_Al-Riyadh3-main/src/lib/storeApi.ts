import { supabase } from '@/lib/supabase';
import type {
  Category,
  CartSelection,
  Order,
  OrderStatus,
  Product,
  PromoCode,
  SiteSettings,
} from '@/types/store';

interface QueryResult<T> {
  data: T | null;
  error: { message: string } | null;
}

function unwrap<T>(result: QueryResult<T>): T {
  if (result.error) throw new Error(result.error.message);
  if (result.data === null) throw new Error('EMPTY_RESPONSE');
  return result.data;
}

export async function fetchCatalog() {
  const [categories, products] = await Promise.all([
    supabase.from('categories').select('*').order('sort_order'),
    supabase.from('products').select('*').order('id'),
  ]);
  return {
    categories: unwrap<Category[]>(categories),
    products: unwrap<Product[]>(products),
  };
}

export async function fetchSettings(): Promise<SiteSettings> {
  const result = await supabase.from('site_settings').select('key, value');
  const rows = unwrap<{ key: string; value: string }[]>(result);
  return Object.fromEntries(rows.map((row) => [row.key, row.value]));
}

export async function fetchPromoPercent(code: string): Promise<number | null> {
  const result = await supabase
    .from('promo_codes')
    .select('percent')
    .eq('code', code)
    .eq('active', true)
    .maybeSingle();
  if (result.error) throw new Error(result.error.message);
  return result.data ? Number(result.data.percent) : null;
}

export interface OrderLinePayload extends CartSelection {
  product_id: string;
  qty: number;
}

export async function placeOrder(lines: OrderLinePayload[], coupon: string | null): Promise<Order> {
  const result = await supabase.rpc('place_order', { p_items: lines, p_coupon: coupon });
  return unwrap<Order>(result);
}

export async function fetchOrders(): Promise<Order[]> {
  const result = await supabase
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(500);
  return unwrap<Order[]>(result);
}

export async function setOrderStatus(orderId: string, status: OrderStatus): Promise<Order> {
  const result = await supabase.rpc('set_order_status', { p_order_id: orderId, p_status: status });
  return unwrap<Order>(result);
}

export async function saveProduct(product: Product): Promise<void> {
  const { error } = await supabase.from('products').upsert(product, { onConflict: 'id' });
  if (error) throw new Error(error.message);
}

export async function updateProductStock(productId: string, stock: number): Promise<void> {
  const { error } = await supabase.from('products').update({ stock }).eq('id', productId);
  if (error) throw new Error(error.message);
}

export async function deleteProduct(productId: string): Promise<void> {
  const { error } = await supabase.from('products').delete().eq('id', productId);
  if (error) throw new Error(error.message);
}

export async function saveSettings(entries: SiteSettings): Promise<void> {
  const rows = Object.entries(entries).map(([key, value]) => ({ key, value }));
  const { error } = await supabase.from('site_settings').upsert(rows, { onConflict: 'key' });
  if (error) throw new Error(error.message);
}

export async function fetchPromoCodes(): Promise<PromoCode[]> {
  const result = await supabase.from('promo_codes').select('*').order('code');
  return unwrap<PromoCode[]>(result);
}

export async function savePromoCode(promo: PromoCode): Promise<void> {
  const { error } = await supabase.from('promo_codes').upsert(promo, { onConflict: 'code' });
  if (error) throw new Error(error.message);
}

export async function deletePromoCode(code: string): Promise<void> {
  const { error } = await supabase.from('promo_codes').delete().eq('code', code);
  if (error) throw new Error(error.message);
}
