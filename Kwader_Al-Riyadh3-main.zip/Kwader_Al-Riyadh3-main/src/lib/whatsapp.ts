import { BRAND } from '@/lib/constants';
import { formatPrice } from '@/lib/format';
import type { Lang, Order } from '@/types/store';

export function buildWhatsappUrl(message: string): string {
  return `https://wa.me/${BRAND.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export function buildOrderMessage(order: Order, lang: Lang): string {
  const lines = order.items.map((item) => {
    const name = lang === 'ar' ? item.name_ar : item.name_en;
    const details = [item.flavor ? (lang === 'ar' ? item.flavor.ar : item.flavor.en) : null, item.nicotine]
      .filter(Boolean)
      .join(' - ');
    const suffix = details ? ` (${details})` : '';
    return `- ${name}${suffix} x${item.qty} = ${formatPrice(item.price * item.qty, lang)}`;
  });

  const summary =
    lang === 'ar'
      ? [
          `طلب جديد رقم ${order.order_number}`,
          '',
          ...lines,
          '',
          `المجموع: ${formatPrice(order.subtotal, lang)}`,
          order.discount > 0 ? `الخصم (${order.coupon_code}): -${formatPrice(order.discount, lang)}` : null,
          `الشحن: ${order.shipping > 0 ? formatPrice(order.shipping, lang) : 'مجاني'}`,
          `الإجمالي: ${formatPrice(order.total, lang)}`,
          '',
          'الاسم:',
          'رقم الجوال:',
          'العنوان:',
        ]
      : [
          `New order ${order.order_number}`,
          '',
          ...lines,
          '',
          `Subtotal: ${formatPrice(order.subtotal, lang)}`,
          order.discount > 0 ? `Discount (${order.coupon_code}): -${formatPrice(order.discount, lang)}` : null,
          `Shipping: ${order.shipping > 0 ? formatPrice(order.shipping, lang) : 'Free'}`,
          `Total: ${formatPrice(order.total, lang)}`,
          '',
          'Name:',
          'Phone:',
          'Address:',
        ];

  return summary.filter((line): line is string => line !== null).join('\n');
}
