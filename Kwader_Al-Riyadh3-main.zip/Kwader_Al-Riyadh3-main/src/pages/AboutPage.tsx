import { Award, Gem, Leaf, ShieldCheck } from 'lucide-react';
import PageHero from '@/components/common/PageHero';
import { usePreferences } from '@/context/PreferencesContext';
import { HERO_PHOTO } from '@/lib/media';

export default function AboutPage() {
  const { tx } = usePreferences();
  const values = [
    { icon: Gem, ar: 'جودة مختارة', en: 'Curated quality', dAr: 'نختار كل منتج بعناية ونتأكد من أصالته قبل عرضه.', dEn: 'We select every product carefully and verify its authenticity before listing it.' },
    { icon: ShieldCheck, ar: 'ثقة وشفافية', en: 'Trust & transparency', dAr: 'أسعار واضحة ومخزون دقيق دون مفاجآت عند الاستلام.', dEn: 'Clear prices and accurate stock with no surprises at delivery.' },
    { icon: Leaf, ar: 'تجربة متوازنة', en: 'Balanced experience', dAr: 'خيارات نيكوتين ونكهات تناسب كل ذوق وكل جلسة.', dEn: 'Nicotine and flavor options that suit every taste and every session.' },
    { icon: Award, ar: 'خدمة راقية', en: 'Refined service', dAr: 'فريق يساعدك في الاختيار ويرد على استفساراتك بسرعة.', dEn: 'A team that helps you choose and answers your questions quickly.' },
  ];

  return (
    <div>
      <PageHero
        eyebrow={tx('من نحن', 'About us')}
        title={tx('كوادر الرياض.. شغف بالجلسة الراقية منذ البداية', 'Kwader Al-Riyadh: a passion for refined sessions')}
        subtitle={tx(
          'شركة كوادر الرياض للشيش والمعسلات متجر متخصص يجمع بين المعسلات الفاخرة والشيش النحاسية والأجهزة الحديثة وكل ما تحتاجه الجلسة، من قلب حي المزاحمية في الرياض.',
          'Kwader Al-Riyadh for Shisha & Molasses is a specialist store combining premium molasses, brass hookahs, modern devices and everything a session needs, from the heart of Al-Muzahimiyah in Riyadh.',
        )}
        image={HERO_PHOTO}
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-16 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
        {values.map(({ icon: Icon, ar, en, dAr, dEn }) => (
          <div key={en} className="card-luxe p-6">
            <span className="mb-5 flex h-12 w-12 items-center justify-center rounded-full bg-gold/15 text-gold-text">
              <Icon size={22} />
            </span>
            <h3 className="font-bold">{tx(ar, en)}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{tx(dAr, dEn)}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
