import { useState, type FormEvent } from 'react';
import { KeyRound, LayoutDashboard, Package, Settings, ArrowLeft, ArrowRight } from 'lucide-react';
import AdminOrders from '@/components/admin/AdminOrders';
import AdminProducts from '@/components/admin/AdminProducts';
import AdminCms from '@/components/admin/AdminCms';
import Logo from '@/components/common/Logo';
import AppLink from '@/components/common/AppLink';
import { usePreferences } from '@/context/PreferencesContext';
import { ADMIN_PIN } from '@/lib/constants';

type AdminTab = 'orders' | 'products' | 'cms';
const SESSION_KEY = 'kwader-admin';

export default function AdminPage() {
  const { tx, lang } = usePreferences();
  const [authorized, setAuthorized] = useState(() => sessionStorage.getItem(SESSION_KEY) === 'yes');
  const [tab, setTab] = useState<AdminTab>('orders');
  const Back = lang === 'ar' ? ArrowRight : ArrowLeft;

  if (!authorized) {
    return (
      <PinGate
        onSuccess={() => {
          sessionStorage.setItem(SESSION_KEY, 'yes');
          setAuthorized(true);
        }}
      />
    );
  }

  const tabs: { id: AdminTab; ar: string; en: string; icon: typeof Package }[] = [
    { id: 'orders', ar: 'الطلبات', en: 'Orders', icon: LayoutDashboard },
    { id: 'products', ar: 'المنتجات والمخزون', en: 'Products & stock', icon: Package },
    { id: 'cms', ar: 'المحتوى والخصومات', en: 'Content & promos', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-bg text-ink">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-4 sm:px-6">
          <div className="flex items-center gap-4">
            <Logo />
            <span className="rounded-full bg-accent px-3 py-1 text-xs font-bold text-white">
              {tx('لوحة الإدارة', 'Admin')}
            </span>
          </div>
          <AppLink to="/" className="btn-outline py-2 text-sm">
            <Back size={16} />
            {tx('العودة للمتجر', 'Back to store')}
          </AppLink>
        </div>
        <nav className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 pb-3 sm:px-6">
          {tabs.map(({ id, ar, en, icon: Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition ${
                tab === id ? 'bg-gold text-black' : 'text-muted hover:text-ink'
              }`}
            >
              <Icon size={16} />
              {tx(ar, en)}
            </button>
          ))}
        </nav>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {tab === 'orders' && <AdminOrders />}
        {tab === 'products' && <AdminProducts />}
        {tab === 'cms' && <AdminCms />}
      </main>
    </div>
  );
}

function PinGate({ onSuccess }: { onSuccess: () => void }) {
  const { tx } = usePreferences();
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (pin === ADMIN_PIN) {
      onSuccess();
    } else {
      setError(true);
      setPin('');
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-bg px-4">
      <form onSubmit={submit} className="card-luxe w-full max-w-sm space-y-6 p-8 text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-gold/15 text-gold-text">
          <KeyRound size={26} />
        </span>
        <div className="space-y-2">
          <h1 className="text-xl font-bold">{tx('دخول الإدارة', 'Admin sign-in')}</h1>
          <p className="text-sm text-muted">{tx('أدخل رمز الدخول للمتابعة', 'Enter the passcode to continue')}</p>
        </div>
        <input
          type="password"
          inputMode="numeric"
          autoFocus
          value={pin}
          onChange={(e) => {
            setPin(e.target.value);
            setError(false);
          }}
          className="input-luxe text-center text-lg tracking-[0.5em]"
          aria-label={tx('رمز الدخول', 'Passcode')}
          aria-invalid={error}
        />
        {error && <p className="text-sm font-semibold text-red-500">{tx('الرمز غير صحيح', 'Incorrect passcode')}</p>}
        <button type="submit" disabled={!pin} className="btn-gold w-full">
          {tx('دخول', 'Sign in')}
        </button>
      </form>
    </div>
  );
}
