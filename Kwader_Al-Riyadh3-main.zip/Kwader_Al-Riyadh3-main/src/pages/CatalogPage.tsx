import { useMemo, useState } from 'react';
import { Search, SearchX, X } from 'lucide-react';
import PageHero from '@/components/common/PageHero';
import ProductCard from '@/components/product/ProductCard';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { filterProducts, type SortOption } from '@/lib/filterProducts';

const PAGE_SIZE = 24;

const SORT_OPTIONS: { value: SortOption; ar: string; en: string }[] = [
  { value: 'featured', ar: 'الأحدث', en: 'Featured' },
  { value: 'price-asc', ar: 'السعر: من الأقل', en: 'Price: low to high' },
  { value: 'price-desc', ar: 'السعر: من الأعلى', en: 'Price: high to low' },
  { value: 'discount', ar: 'أعلى خصم', en: 'Biggest discount' },
];

export default function CatalogPage() {
  const { tx, lang } = usePreferences();
  const { products, categories, filters, updateFilters, resetFilters } = useCatalog();
  const [visible, setVisible] = useState(PAGE_SIZE);

  const results = useMemo(() => filterProducts(products, filters), [products, filters]);
  const shown = results.slice(0, visible);
  const activeCategory = categories.find((c) => c.id === filters.categoryId) ?? null;
  const hasActiveFilters =
    filters.search !== '' ||
    filters.categoryId !== null ||
    filters.priceRange !== null ||
    filters.flavors.length > 0 ||
    filters.nicotine.length > 0 ||
    filters.inStockOnly;

  const changeFilters = (patch: Parameters<typeof updateFilters>[0]) => {
    setVisible(PAGE_SIZE);
    updateFilters(patch);
  };

  return (
    <div>
      <PageHero
        eyebrow={tx('المتجر', 'The shop')}
        title={tx('كل منتجاتنا', 'Our full collection')}
        subtitle={tx(
          'تصفح الأقسام، استخدم الفلاتر من القائمة الجانبية، وأضف ما يعجبك إلى السلة مباشرة.',
          'Browse categories, use the filters in the side menu, and add your favorites to the cart.',
        )}
      />

      <div className="mx-auto max-w-7xl space-y-8 px-4 py-10 sm:px-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative w-full lg:max-w-md">
            <Search size={18} className="pointer-events-none absolute start-4 top-1/2 -translate-y-1/2 text-muted" />
            <input
              type="search"
              value={filters.search}
              onChange={(e) => changeFilters({ search: e.target.value })}
              placeholder={tx('ابحث عن منتج...', 'Search products...')}
              className="input-luxe ps-11"
              aria-label={tx('بحث', 'Search')}
            />
          </div>
          <div className="flex items-center gap-3">
            <select
              value={filters.sort}
              onChange={(e) => changeFilters({ sort: e.target.value as SortOption })}
              className="input-luxe w-auto py-2.5"
              aria-label={tx('ترتيب', 'Sort')}
            >
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {tx(option.ar, option.en)}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2">
          <button
            type="button"
            onClick={() => changeFilters({ categoryId: null })}
            className={`shrink-0 rounded-full border px-4 py-2 text-sm font-semibold transition ${
              filters.categoryId === null ? 'border-gold bg-gold text-black' : 'border-line bg-surface hover:border-gold'
            }`}
          >
            {tx('الكل', 'All')}
          </button>
          {categories.map((category) => (
            <button
              key={category.id}
              type="button"
              onClick={() => changeFilters({ categoryId: category.id })}
              className={`shrink-0 rounded-full border px-4 py-2 text-sm font-semibold transition ${
                filters.categoryId === category.id
                  ? 'border-gold bg-gold text-black'
                  : 'border-line bg-surface hover:border-gold'
              }`}
            >
              {lang === 'ar' ? category.name_ar : category.name_en}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
          <p className="text-muted">
            {tx(`${results.length} منتج`, `${results.length} products`)}
            {activeCategory && (
              <span className="ms-2 text-ink">· {lang === 'ar' ? activeCategory.name_ar : activeCategory.name_en}</span>
            )}
          </p>
          {hasActiveFilters && (
            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-gold-text hover:underline"
            >
              <X size={14} />
              {tx('مسح الفلاتر', 'Clear filters')}
            </button>
          )}
        </div>

        {results.length === 0 ? (
          <div className="flex flex-col items-center gap-4 rounded-3xl border border-dashed border-line py-20 text-center">
            <SearchX size={40} className="text-muted" />
            <p className="font-semibold">{tx('لا توجد منتجات تطابق بحثك', 'No products match your search')}</p>
            <button type="button" onClick={resetFilters} className="btn-outline">
              {tx('إعادة ضبط الفلاتر', 'Reset filters')}
            </button>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-3 xl:grid-cols-4">
              {shown.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
            {visible < results.length && (
              <div className="flex justify-center">
                <button type="button" onClick={() => setVisible((v) => v + PAGE_SIZE)} className="btn-outline">
                  {tx('عرض المزيد', 'Show more')}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
