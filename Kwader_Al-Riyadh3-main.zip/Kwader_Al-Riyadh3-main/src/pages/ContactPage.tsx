import { useState, type FormEvent } from 'react';
import { MessageCircle, Phone } from 'lucide-react';
import PageHero from '@/components/common/PageHero';
import LocationSection from '@/components/home/LocationSection';
import { usePreferences } from '@/context/PreferencesContext';
import { BRAND } from '@/lib/constants';
import { buildWhatsappUrl } from '@/lib/whatsapp';

export default function ContactPage() {
  const { tx } = usePreferences();
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    const text = tx(
      `مرحباً، أنا ${name || 'عميل'}.\n${message}`,
      `Hello, I am ${name || 'a customer'}.\n${message}`,
    );
    window.open(buildWhatsappUrl(text), '_blank', 'noopener,noreferrer');
  };

  return (
    <div>
      <PageHero
        eyebrow={tx('تواصل معنا', 'Contact')}
        title={tx('نسعد باستفساراتك', "We'd love to hear from you")}
        subtitle={tx('أرسل رسالتك وسيتم تحويلها مباشرة إلى واتساب فريقنا.', 'Send your message and it will open directly in our team WhatsApp.')}
      />
      <section className="mx-auto grid max-w-7xl gap-8 px-4 py-16 sm:px-6 lg:grid-cols-2">
        <form onSubmit={handleSubmit} className="card-luxe space-y-5 p-6 sm:p-8">
          <div className="space-y-2">
            <label htmlFor="contact-name" className="text-sm font-semibold">{tx('الاسم', 'Name')}</label>
            <input id="contact-name" value={name} onChange={(e) => setName(e.target.value)} className="input-luxe" />
          </div>
          <div className="space-y-2">
            <label htmlFor="contact-message" className="text-sm font-semibold">{tx('رسالتك', 'Your message')}</label>
            <textarea
              id="contact-message"
              required
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="input-luxe resize-none"
            />
          </div>
          <div className="flex flex-wrap gap-3">
            <button type="submit" disabled={!message.trim()} className="btn-gold">
              <MessageCircle size={18} />
              {tx('إرسال عبر الواتساب', 'Send via WhatsApp')}
            </button>
            <a href={`tel:${BRAND.phoneTel}`} className="btn-outline">
              <Phone size={16} />
              {BRAND.phoneDisplay}
            </a>
          </div>
        </form>
        <div className="flex items-center text-muted">
          <p className="leading-relaxed">
            {tx(
              'يمكنك أيضاً زيارتنا في المزاحمية أو الاتصال بنا خلال ساعات العمل. نحرص على الرد بسرعة على جميع الاستفسارات.',
              'You can also visit us in Al-Muzahimiyah or call during working hours. We aim to reply to every inquiry quickly.',
            )}
          </p>
        </div>
      </section>
      <LocationSection />
    </div>
  );
}
