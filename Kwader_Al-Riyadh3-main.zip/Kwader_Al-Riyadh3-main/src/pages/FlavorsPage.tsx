import { Cherry, CakeSlice, Citrus, Leaf } from 'lucide-react';
import PageHero from '@/components/common/PageHero';
import { useCatalog } from '@/context/CatalogContext';
import { useNavigation } from '@/context/NavigationContext';
import { usePreferences } from '@/context/PreferencesContext';
import type { FlavorProfile } from '@/types/store';

const PROFILES: { value: FlavorProfile; ar: string; en: string; dAr: string; dEn: string; icon: typeof Leaf }[] = [
  { value: 'fruit', ar: 'فواكه', en: 'Fruits', dAr: 'توت وتفاح وعنب ومانجو بطعم منعش.', dEn: 'Berry, apple, grape and mango with a fresh taste.', icon: Cherry },
  { value: 'mint', ar: 'نعناع', en: 'Mint', dAr: 'برودة نقية تكمل أي خلطة.', dEn: 'A clean cooling note that complements any blend.', icon: Leaf },
  { value: 'citrus', ar: 'حوامض', en: 'Citrus', dAr: 'ليمون وبرتقال لجلسة خفيفة ومنعشة.', dEn: 'Lemon and orange for a light, refreshing session.', icon: Citrus },
  { value: 'dessert', ar: 'حلا', en: 'Dessert', dAr: 'كراميل وقهوة لنكهات غنية وناعمة.', dEn: 'Caramel and coffee for rich, smooth flavors.', icon: CakeSlice },
];

export default function FlavorsPage() {
  const { tx } = usePreferences();
  const { updateFilters } = useCatalog();
  const { navigate } = useNavigation();

  return (
    <div>
      <PageHero
        eyebrow={tx('خلطات النكهات', 'Flavor blends')}
        title={tx('اختر ملف نكهتك المفضل', 'Choose your favorite flavor profile')}
        subtitle={tx('كل ملف نكهة يضم مجموعة مختارة من المنتجات. اضغط لعرض المنتجات.', 'Each profile groups a curated selection of products. Tap to browse them.')}
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-16 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
        {PROFILES.map(({ value, ar, en, dAr, dEn, icon: Icon }) => (
          <button
            key={value}
            type="button"
            onClick={() => {
              updateFilters({ flavors: [value], categoryId: null, search: '' });
              navigate('/catalog');
            }}
            className="card-luxe group p-7 text-start transition hover:-translate-y-1 hover:border-gold/60"
          >
            <span className="mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-gold/15 text-gold-text transition group-hover:bg-gold group-hover:text-black">
              <Icon size={26} />
            </span>
            <h3 className="text-lg font-bold">{tx(ar, en)}</h3>
            <p className="mt-2 text-sm leading-relaxed text-muted">{tx(dAr, dEn)}</p>
          </button>
        ))}
      </section>
    </div>
  );
}
