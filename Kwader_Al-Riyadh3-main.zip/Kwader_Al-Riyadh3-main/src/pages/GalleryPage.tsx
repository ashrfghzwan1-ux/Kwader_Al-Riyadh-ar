import { useState } from 'react';
import { motion } from 'framer-motion';
import PageHero from '@/components/common/PageHero';
import Modal from '@/components/common/Modal';
import { usePreferences } from '@/context/PreferencesContext';
import { GALLERY_PHOTOS } from '@/lib/media';

export default function GalleryPage() {
  const { tx } = usePreferences();
  const [active, setActive] = useState<number | null>(null);
  const photo = active === null ? null : GALLERY_PHOTOS[active];

  return (
    <div>
      <PageHero
        eyebrow={tx('معرض الصور', 'Gallery')}
        title={tx('نظرة على منتجاتنا', 'A look at our products')}
        subtitle={tx('صور حقيقية للمنتجات المتوفرة في متجرنا.', 'Real imagery of the products available in our store.')}
      />
      <section className="mx-auto grid max-w-7xl grid-cols-2 gap-4 px-4 py-16 sm:px-6 lg:grid-cols-3">
        {GALLERY_PHOTOS.map((item, index) => (
          <motion.button
            key={item.url}
            type="button"
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            onClick={() => setActive(index)}
            className="group relative aspect-square overflow-hidden rounded-2xl border border-line"
          >
            <img src={item.url} alt={tx(item.ar, item.en)} loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
            <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/85 to-transparent p-4 text-start text-sm font-semibold text-white">
              {tx(item.ar, item.en)}
            </span>
          </motion.button>
        ))}
      </section>
      <Modal open={photo !== null} onClose={() => setActive(null)} title={photo ? tx(photo.ar, photo.en) : ''} size="lg">
        {photo && <img src={photo.url} alt={tx(photo.ar, photo.en)} className="max-h-[70vh] w-full rounded-2xl object-contain" />}
      </Modal>
    </div>
  );
}
