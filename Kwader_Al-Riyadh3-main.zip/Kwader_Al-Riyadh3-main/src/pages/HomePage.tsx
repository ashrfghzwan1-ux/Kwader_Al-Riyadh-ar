import { motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, Truck } from 'lucide-react';
import AppLink from '@/components/common/AppLink';
import ProductCard from '@/components/product/ProductCard';
import LocationSection from '@/components/home/LocationSection';
import ReviewsCarousel from '@/components/home/ReviewsCarousel';
import { useCatalog } from '@/context/CatalogContext';
import { useNavigation } from '@/context/NavigationContext';
import { usePreferences } from '@/context/PreferencesContext';
import { CATEGORY_PHOTOS, HERO_PHOTO } from '@/lib/media';

export default function HomePage() {
  const { tx, lang } = usePreferences();
  const { categories, products, updateFilters, freeShippingThreshold } = useCatalog();
  const { navigate } = useNavigation();
  const Arrow = lang === 'ar' ? ArrowLeft : ArrowRight;

  const featured = products.filter((p) => p.stock > 0 && p.compare_at_price).slice(0, 8);

  return (
    <div>
      <section className="relative isolate overflow-hidden">
        <img src={HERO_PHOTO} alt="" className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-bg/60 via-bg/85 to-bg" />
        <div className="mx-auto grid max-w-7xl gap-10 px-4 py-20 sm:px-6 md:py-32 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="space-y-7"
          >
            <p className="eyebrow">{tx('منذ تأسيسنا في الرياض', 'Crafted for Riyadh since day one')}</p>
            <h1 className="text-4xl font-bold leading-[1.2] sm:text-6xl">
              {tx('كوادر الرياض', 'Kwader Al-Riyadh')}
              <span className="mt-2 block text-gold-text">
                {tx('للشيش والمعسلات الفاخرة', 'Luxury Shisha & Molasses')}
              </span>
            </h1>
            <p className="max-w-xl text-base leading-relaxed text-muted sm:text-lg">
              {tx(
                'أكثر من 500 منتج مختار بعناية: معسلات فاخرة، شيش نحاسية، سحبات إلكترونية، وإكسسوارات الجلسة الكاملة مع توصيل سريع.',
                'Over 500 carefully selected products: premium molasses, brass hookahs, disposable vapes and complete session accessories with fast delivery.',
              )}
            </p>
            <div className="flex flex-wrap gap-4">
              <AppLink to="/catalog" className="btn-gold">
                {tx('تسوق الآن', 'Shop now')}
                <Arrow size={18} />
              </AppLink>
              <AppLink to="/offers" className="btn-outline">
                {tx('عروض اليوم', "Today's offers")}
              </AppLink>
            </div>
            <p className="flex items-center gap-2 text-sm text-muted">
              <Truck size={16} className="text-emerald" />
              {tx(
                `شحن مجاني للطلبات فوق ${freeShippingThreshold} ر.س`,
                `Free shipping on orders over ${freeShippingThreshold} SAR`,
              )}
            </p>
          </motion.div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">{tx('الأقسام', 'Collections')}</p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">{tx('تسوق حسب القسم', 'Shop by category')}</h2>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {categories.map((category, index) => {
            const count = products.filter((p) => p.category_id === category.id).length;
            return (
              <motion.button
                key={category.id}
                type="button"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                onClick={() => {
                  updateFilters({ categoryId: category.id, search: '' });
                  navigate('/catalog');
                }}
                className="group relative aspect-[4/5] overflow-hidden rounded-2xl border border-line text-start"
              >
                <img
                  src={CATEGORY_PHOTOS[category.id]}
                  alt=""
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-4">
                  <p className="text-base font-bold text-white">{tx(category.name_ar, category.name_en)}</p>
                  <p className="text-xs text-white/75">
                    {count} {tx('منتج', 'products')}
                  </p>
                </div>
              </motion.button>
            );
          })}
        </div>
      </section>

      {featured.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6">
          <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">{tx('عروض مميزة', 'Highlights')}</p>
              <h2 className="mt-3 text-3xl font-bold sm:text-4xl">{tx('خصومات تستحق الاكتشاف', 'Offers worth discovering')}</h2>
            </div>
            <AppLink to="/offers" className="text-sm font-semibold text-gold-text hover:underline">
              {tx('كل العروض', 'All offers')}
            </AppLink>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            {featured.slice(0, 4).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}

      <ReviewsCarousel />
      <LocationSection />
    </div>
  );
}
