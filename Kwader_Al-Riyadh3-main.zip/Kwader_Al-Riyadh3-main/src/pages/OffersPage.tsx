import PageHero from '@/components/common/PageHero';
import ProductCard from '@/components/product/ProductCard';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { discountPercent } from '@/lib/format';

export default function OffersPage() {
  const { tx } = usePreferences();
  const { products } = useCatalog();
  const offers = products
    .filter((p) => p.compare_at_price && p.compare_at_price > p.price && p.stock > 0)
    .sort((a, b) => discountPercent(b.price, b.compare_at_price) - discountPercent(a.price, a.compare_at_price));

  return (
    <div>
      <PageHero
        eyebrow={tx('عروض اليوم', "Today's offers")}
        title={tx('خصومات حصرية على أفضل المنتجات', 'Exclusive savings on our best products')}
        subtitle={tx(
          'استخدم كود الخصم K01 عند الدفع واحصل على 10% إضافية على طلبك.',
          'Use coupon code K01 at checkout to get an extra 10% off your order.',
        )}
      />
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        {offers.length === 0 ? (
          <p className="py-20 text-center text-muted">{tx('لا توجد عروض متاحة حالياً', 'No offers available right now')}</p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            {offers.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
