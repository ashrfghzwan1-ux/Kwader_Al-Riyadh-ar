import { useState, type ReactNode } from 'react';
import { ArrowLeft, ArrowRight, Minus, MessageCircle, Plus, ShoppingBag } from 'lucide-react';
import AppLink from '@/components/common/AppLink';
import ProductCard from '@/components/product/ProductCard';
import { useCart } from '@/context/CartContext';
import { useCatalog } from '@/context/CatalogContext';
import { usePreferences } from '@/context/PreferencesContext';
import { discountPercent, formatPrice } from '@/lib/format';
import { buildWhatsappUrl } from '@/lib/whatsapp';
import type { FlavorOption } from '@/types/store';

interface ProductPageProps {
  productId: string;
}

export default function ProductPage({ productId }: ProductPageProps) {
  const { tx, lang } = usePreferences();
  const { products, categories } = useCatalog();
  const { addItem } = useCart();
  const product = products.find((p) => p.id === productId);
  const [flavor, setFlavor] = useState<FlavorOption | null>(null);
  const [nicotine, setNicotine] = useState<string | null>(null);
  const [qty, setQty] = useState(1);
  const Back = lang === 'ar' ? ArrowRight : ArrowLeft;

  if (!product) {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center gap-4 px-6 py-32 text-center">
        <p className="text-lg font-bold">{tx('هذا المنتج غير متوفر', 'This product is not available')}</p>
        <AppLink to="/catalog" className="btn-primary">
          {tx('العودة للمتجر', 'Back to the shop')}
        </AppLink>
      </div>
    );
  }

  const name = lang === 'ar' ? product.name_ar : product.name_en;
  const description = lang === 'ar' ? product.description_ar : product.description_en;
  const category = categories.find((c) => c.id === product.category_id);
  const off = discountPercent(product.price, product.compare_at_price);
  const soldOut = product.stock <= 0;
  const selectedFlavor = flavor ?? product.flavor_options[0] ?? null;
  const selectedNicotine = nicotine ?? product.nicotine_levels[0] ?? null;
  const related = products
    .filter((p) => p.category_id === product.category_id && p.id !== product.id && p.stock > 0)
    .slice(0, 4);

  const handleAdd = () => {
    for (let i = 0; i < qty; i += 1) {
      addItem(product, { flavor: selectedFlavor, nicotine: selectedNicotine });
    }
  };

  const whatsappMessage = tx(
    `مرحباً، أود طلب: ${product.name_ar} (${product.id})`,
    `Hello, I would like to order: ${product.name_en} (${product.id})`,
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-16">
      <AppLink to="/catalog" className="mb-8 inline-flex items-center gap-2 text-sm font-semibold text-muted hover:text-gold-text">
        <Back size={16} />
        {tx('العودة للمتجر', 'Back to the shop')}
      </AppLink>

      <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
        <div className="relative aspect-square overflow-hidden rounded-3xl border border-line bg-surface-2 shadow-lift">
          <img src={product.image_url} alt={name} className="h-full w-full object-cover" />
          {off > 0 && !soldOut && (
            <span className="absolute start-5 top-5 rounded-full bg-accent px-3 py-1.5 text-sm font-bold text-white">
              -{off}%
            </span>
          )}
        </div>

        <div className="flex flex-col gap-7">
          <div className="space-y-3">
            {category && (
              <p className="eyebrow">{lang === 'ar' ? category.name_ar : category.name_en}</p>
            )}
            <h1 className="text-3xl font-bold leading-tight sm:text-4xl">{name}</h1>
            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-bold text-gold-text">{formatPrice(product.price, lang)}</span>
              {product.compare_at_price && product.compare_at_price > product.price && (
                <span className="text-sm text-muted line-through">{formatPrice(product.compare_at_price, lang)}</span>
              )}
            </div>
            <p className="text-sm font-semibold">
              {soldOut ? (
                <span className="text-red-500">{tx('نفدت الكمية', 'Sold out')}</span>
              ) : (
                <span className="text-emerald">
                  {tx(`متوفر (${product.stock} قطعة)`, `In stock (${product.stock} units)`)}
                </span>
              )}
            </p>
          </div>

          <p className="text-base leading-relaxed text-muted">{description}</p>

          {product.flavor_options.length > 0 && (
            <OptionGroup label={tx('اختر النكهة', 'Choose a flavor')}>
              {product.flavor_options.map((option) => (
                <OptionChip
                  key={option.en}
                  active={selectedFlavor?.en === option.en}
                  onClick={() => setFlavor(option)}
                  tone="gold"
                >
                  {tx(option.ar, option.en)}
                </OptionChip>
              ))}
            </OptionGroup>
          )}

          {product.nicotine_levels.length > 0 && (
            <OptionGroup label={tx('قوة النيكوتين', 'Nicotine strength')}>
              {product.nicotine_levels.map((level) => (
                <OptionChip
                  key={level}
                  active={selectedNicotine === level}
                  onClick={() => setNicotine(level)}
                  tone="emerald"
                >
                  {level}
                </OptionChip>
              ))}
            </OptionGroup>
          )}

          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2 rounded-full border border-line bg-surface p-1.5">
              <button
                type="button"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="flex h-9 w-9 items-center justify-center rounded-full transition hover:text-gold-text"
                aria-label={tx('تقليل الكمية', 'Decrease quantity')}
              >
                <Minus size={16} />
              </button>
              <span className="w-8 text-center font-bold">{qty}</span>
              <button
                type="button"
                onClick={() => setQty((q) => Math.min(q + 1, product.stock))}
                disabled={soldOut || qty >= product.stock}
                className="flex h-9 w-9 items-center justify-center rounded-full transition hover:text-gold-text disabled:opacity-40"
                aria-label={tx('زيادة الكمية', 'Increase quantity')}
              >
                <Plus size={16} />
              </button>
            </div>
            <button type="button" onClick={handleAdd} disabled={soldOut} className="btn-primary flex-1 sm:flex-none sm:px-10">
              <ShoppingBag size={18} />
              {soldOut ? tx('نفدت الكمية', 'Sold out') : tx('إضافة للسلة', 'Add to cart')}
            </button>
          </div>

          <a
            href={buildWhatsappUrl(whatsappMessage)}
            target="_blank"
            rel="noreferrer"
            className="btn-outline w-full sm:w-auto"
          >
            <MessageCircle size={18} className="text-emerald" />
            {tx('استفسر عن المنتج عبر الواتساب', 'Ask about this product on WhatsApp')}
          </a>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-24 space-y-8">
          <h2 className="text-2xl font-bold sm:text-3xl">{tx('منتجات مشابهة', 'Similar products')}</h2>
          <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
            {related.map((item) => (
              <ProductCard key={item.id} product={item} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function OptionGroup({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-3">
      <p className="text-sm font-semibold">{label}</p>
      <div className="flex flex-wrap gap-2">{children}</div>
    </div>
  );
}

function OptionChip({
  active,
  onClick,
  tone,
  children,
}: {
  active: boolean;
  onClick: () => void;
  tone: 'gold' | 'emerald';
  children: ReactNode;
}) {
  const activeClass = tone === 'gold' ? 'border-gold bg-gold text-black' : 'border-emerald bg-emerald text-white';
  const hoverClass = tone === 'gold' ? 'hover:border-gold' : 'hover:border-emerald';
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
        active ? activeClass : `border-line bg-surface ${hoverClass}`
      }`}
    >
      {children}
    </button>
  );
}
