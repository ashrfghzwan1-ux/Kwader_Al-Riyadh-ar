import { Gift, Package, Truck, Users } from 'lucide-react';
import PageHero from '@/components/common/PageHero';
import AppLink from '@/components/common/AppLink';
import { usePreferences } from '@/context/PreferencesContext';

export default function ServicesPage() {
  const { tx } = usePreferences();
  const services = [
    { icon: Truck, ar: 'توصيل سريع', en: 'Fast delivery', dAr: 'توصيل داخل الرياض، وشحن مجاني للطلبات فوق 200 ر.س.', dEn: 'Delivery across Riyadh, free shipping on orders over 200 SAR.' },
    { icon: Users, ar: 'استشارة الاختيار', en: 'Selection advice', dAr: 'نساعدك في اختيار الشيشة والخلطة المناسبة لذوقك.', dEn: 'We help you choose the hookah and blend that suit your taste.' },
    { icon: Package, ar: 'طلبات الجملة', en: 'Wholesale orders', dAr: 'أسعار خاصة للمحلات والمقاهي عند الطلب بكميات.', dEn: 'Special prices for shops and cafes ordering in bulk.' },
    { icon: Gift, ar: 'تغليف الهدايا', en: 'Gift packaging', dAr: 'تغليف أنيق للهدايا بالمناسبات والأعياد.', dEn: 'Elegant gift packaging for occasions and holidays.' },
  ];

  return (
    <div>
      <PageHero
        eyebrow={tx('الخدمات', 'Services')}
        title={tx('خدمات تليق بجلستك', 'Services made for your session')}
        subtitle={tx('من الاختيار حتى باب منزلك، نهتم بكل تفصيلة.', 'From choosing to your doorstep, we care about every detail.')}
      />
      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-16 sm:grid-cols-2 sm:px-6">
        {services.map(({ icon: Icon, ar, en, dAr, dEn }) => (
          <div key={en} className="card-luxe flex gap-5 p-7">
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gold/15 text-gold-text">
              <Icon size={22} />
            </span>
            <div>
              <h3 className="font-bold">{tx(ar, en)}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted">{tx(dAr, dEn)}</p>
            </div>
          </div>
        ))}
      </section>
      <div className="pb-20 text-center">
        <AppLink to="/contact" className="btn-primary">
          {tx('تواصل معنا', 'Contact us')}
        </AppLink>
      </div>
    </div>
  );
}
