export type Lang = 'ar' | 'en';
export type Theme = 'dark' | 'light';
export type FlavorProfile = 'fruit' | 'mint' | 'citrus' | 'dessert' | 'none';
export type OrderStatus = 'new' | 'preparing' | 'delivered' | 'cancelled';

export interface Category {
  id: string;
  name_ar: string;
  name_en: string;
  sort_order: number;
}

export interface FlavorOption {
  ar: string;
  en: string;
}

export interface Product {
  id: string;
  category_id: string;
  name_ar: string;
  name_en: string;
  description_ar: string;
  description_en: string;
  price: number;
  compare_at_price: number | null;
  stock: number;
  image_url: string;
  flavor_profile: FlavorProfile;
  flavor_options: FlavorOption[];
  nicotine_levels: string[];
}

export interface CartSelection {
  flavor: FlavorOption | null;
  nicotine: string | null;
}

export interface OrderItem extends CartSelection {
  product_id: string;
  name_ar: string;
  name_en: string;
  price: number;
  qty: number;
}

export interface Order {
  id: string;
  order_number: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  coupon_code: string | null;
  status: OrderStatus;
  created_at: string;
  updated_at: string;
}

export interface PromoCode {
  code: string;
  percent: number;
  active: boolean;
}

export type SiteSettings = Record<string, string>;
