/*
# Create store schema (categories, products, orders, settings, promo codes)

1. New Tables
- `categories`: the 7 shop categories, bilingual names and display order.
- `products`: catalog items with bilingual names/descriptions, SAR price, optional compare-at price (drives discount badges), stock counter, image URL, flavor profile, flavor options and nicotine levels.
- `orders`: confirmed orders with item snapshot, subtotal, discount, shipping, total, coupon and status (new, preparing, delivered, cancelled).
- `site_settings`: key/value store for announcement, address, working hours, shipping and contact CMS values.
- `promo_codes`: coupon codes with percentage and active flag.

2. Security
- RLS enabled on every table.
- The app has no sign-in screen, so policies target `anon` and `authenticated`.
- Orders are only created and status-changed through database functions (added in a later migration), so orders get SELECT only.

3. Notes
- Stock is never changed by this migration. Stock deduction is handled by the order function.
- Indexes added on foreign keys and sort columns.
*/

CREATE TABLE IF NOT EXISTS categories (
  id text PRIMARY KEY,
  name_ar text NOT NULL,
  name_en text NOT NULL,
  sort_order int NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
  id text PRIMARY KEY,
  category_id text NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
  name_ar text NOT NULL,
  name_en text NOT NULL,
  description_ar text NOT NULL DEFAULT '',
  description_en text NOT NULL DEFAULT '',
  price numeric(10,2) NOT NULL CHECK (price >= 0),
  compare_at_price numeric(10,2) CHECK (compare_at_price >= 0),
  stock int NOT NULL DEFAULT 0 CHECK (stock >= 0),
  image_url text NOT NULL DEFAULT '',
  flavor_profile text NOT NULL DEFAULT 'none' CHECK (flavor_profile IN ('fruit','mint','citrus','dessert','none')),
  flavor_options jsonb NOT NULL DEFAULT '[]'::jsonb,
  nicotine_levels text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS products_category_idx ON products (category_id);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text NOT NULL UNIQUE,
  items jsonb NOT NULL,
  subtotal numeric(10,2) NOT NULL CHECK (subtotal >= 0),
  discount numeric(10,2) NOT NULL DEFAULT 0 CHECK (discount >= 0),
  shipping numeric(10,2) NOT NULL DEFAULT 0 CHECK (shipping >= 0),
  total numeric(10,2) NOT NULL CHECK (total >= 0),
  coupon_code text,
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new','preparing','delivered','cancelled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS orders_created_idx ON orders (created_at DESC);

CREATE TABLE IF NOT EXISTS site_settings (
  key text PRIMARY KEY,
  value text NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS promo_codes (
  code text PRIMARY KEY,
  percent int NOT NULL CHECK (percent BETWEEN 1 AND 100),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE promo_codes ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON categories TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON products TO anon, authenticated;
GRANT SELECT ON orders TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON site_settings TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON promo_codes TO anon, authenticated;

DROP POLICY IF EXISTS "public_select_categories" ON categories;
CREATE POLICY "public_select_categories" ON categories FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_products" ON products;
CREATE POLICY "public_select_products" ON products FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "public_insert_products" ON products;
CREATE POLICY "public_insert_products" ON products FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "public_update_products" ON products;
CREATE POLICY "public_update_products" ON products FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "public_delete_products" ON products;
CREATE POLICY "public_delete_products" ON products FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_orders" ON orders;
CREATE POLICY "public_select_orders" ON orders FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_settings" ON site_settings;
CREATE POLICY "public_select_settings" ON site_settings FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "public_insert_settings" ON site_settings;
CREATE POLICY "public_insert_settings" ON site_settings FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "public_update_settings" ON site_settings;
CREATE POLICY "public_update_settings" ON site_settings FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "public_select_promos" ON promo_codes;
CREATE POLICY "public_select_promos" ON promo_codes FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "public_insert_promos" ON promo_codes;
CREATE POLICY "public_insert_promos" ON promo_codes FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "public_update_promos" ON promo_codes;
CREATE POLICY "public_update_promos" ON promo_codes FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "public_delete_promos" ON promo_codes;
CREATE POLICY "public_delete_promos" ON promo_codes FOR DELETE
  TO anon, authenticated USING (true);
