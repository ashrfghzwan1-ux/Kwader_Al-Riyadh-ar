/*
# Seed categories, site settings and promo codes

1. Categories
- Seven shop categories in Arabic and English with display order.

2. Site settings
- Announcement ticker, address, working hours, phone, shipping fee and free-shipping threshold.

3. Promo codes
- K01 gives 10% off.

4. Notes
- Uses fixed ids and ON CONFLICT DO NOTHING, so re-running is safe and never overwrites admin edits.
*/

INSERT INTO categories (id, name_ar, name_en, sort_order) VALUES
  ('premium-molasses', 'معسلات فاخرة', 'Premium Molasses', 1),
  ('e-vapes', 'سحبات إلكترونية', 'Disposable Vapes', 2),
  ('flavors-salts', 'نكهات وسولت', 'Flavors & Salts', 3),
  ('hookahs', 'شيش فاخرة', 'Luxury Hookahs', 4),
  ('devices-pods', 'أجهزة وبودات', 'Devices & Pods', 5),
  ('charcoal-accessories', 'مستلزمات وفحم', 'Charcoal & Supplies', 6),
  ('papers-accessories', 'ورق لف وإكسسوارات', 'Papers & Accessories', 7)
ON CONFLICT (id) DO NOTHING;

INSERT INTO site_settings (key, value) VALUES
  ('announcement_ar', 'شحن مجاني للطلبات فوق 200 ر.س | خصم 10% بكود K01 | توصيل سريع داخل الرياض'),
  ('announcement_en', 'Free shipping on orders over 200 SAR | 10% off with code K01 | Fast delivery across Riyadh'),
  ('address_ar', 'غرناطة، المزاحمية 19672، المملكة العربية السعودية'),
  ('address_en', 'Granada, Al-Muzahimiyah 19672, Kingdom of Saudi Arabia'),
  ('hours_main_ar', 'السبت - الخميس: 10:00 ص - 12:00 م'),
  ('hours_main_en', 'Sat - Thu: 10:00 AM - 12:00 AM'),
  ('hours_friday_ar', 'الجمعة: 4:00 م - 12:00 م'),
  ('hours_friday_en', 'Friday: 4:00 PM - 12:00 AM'),
  ('phone', '+966 56 094 0585'),
  ('whatsapp', '966560940585'),
  ('shipping_fee', '20'),
  ('free_shipping_threshold', '200')
ON CONFLICT (key) DO NOTHING;

INSERT INTO promo_codes (code, percent, active) VALUES ('K01', 10, true)
ON CONFLICT (code) DO NOTHING;
