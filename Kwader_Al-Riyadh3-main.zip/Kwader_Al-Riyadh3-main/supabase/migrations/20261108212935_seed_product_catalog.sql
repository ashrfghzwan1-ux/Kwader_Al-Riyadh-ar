/*
# Seed 520-item product catalog

1. New Data
- 520 products spread across the 7 categories, with generated bilingual names and descriptions.
- Prices in SAR, with a compare-at price on every 5th item so discount badges appear.
- Stock counts between 0 and 59. Items with 0 stock show as sold out.
- Flavored categories get 3 flavor options and a flavor profile. Liquid, vape and device categories get nicotine levels.

2. Security
- No security changes. Data is inserted with fixed ids (KW-0001 to KW-0520), so re-running is safe and never overwrites admin edits.

3. Notes
- Product photos are product-only stock images. Admins can replace any image URL from the product editor.
*/

DO $$
DECLARE
  cat_ids text[] := ARRAY['premium-molasses','e-vapes','flavors-salts','hookahs','devices-pods','charcoal-accessories','papers-accessories'];
  cat_ar text[] := ARRAY['معسل فاخر','سحبة إلكترونية','سائل ونكهة','شيشة فاخرة','جهاز وبود','فحم وطبق','ورق لف'];
  cat_en text[] := ARRAY['Premium Molasses','Disposable Vape','Flavor Concentrate','Luxury Hookah','Device & Pod','Charcoal & Bowl','Rolling Papers'];
  cat_desc_ar text[] := ARRAY[
    'معسل فاخر بتركيبة متوازنة ونكهة عميقة، مختار بعناية من كوادر الرياض.',
    'سحبة إلكترونية بتصميم أنيق وعمر بطارية طويل ونكهات متنوعة.',
    'سوائل ونكهات مركزة بجودة عالية وتركيبة نقية.',
    'شيشة فاخرة بتشطيبات أنيقة وقاعدة متينة تمنح جلسة مميزة.',
    'جهاز وبود بتقنية حديثة وتشغيل مستقر وسهل الاستخدام.',
    'فحم طبيعي عالي الحرارة وطبق للتقديم بجودة فاخرة.',
    'ورق لف وإكسسوارات بجودة ممتازة للجلسات اليومية والخاصة.'];
  cat_desc_en text[] := ARRAY[
    'Premium molasses with a balanced blend and deep flavor, carefully selected by Kwader Al-Riyadh.',
    'Disposable vape with an elegant design, long battery life and a range of flavors.',
    'High-quality concentrated flavors with a pure blend.',
    'Luxury hookah with elegant finishing and a sturdy base for a distinctive session.',
    'Modern device and pod with stable performance and easy operation.',
    'Natural high-heat charcoal and a premium serving bowl.',
    'Premium rolling papers and accessories for everyday and special sessions.'];
  cat_base numeric[] := ARRAY[85,45,35,320,120,18,12];
  photo_ids bigint[] := ARRAY[16624534,13564526,30801235,33298190,40447754,34776659,31251024,4173383,30801235,774378,8863347,774378,33298190,40447754,31251024,8863347,10005648,39185938,16624534,40447754,13564526];
  series_ar text[] := ARRAY['الملكي','الذهبي','الكريستال','الرياض','النخبة','العنبر'];
  series_en text[] := ARRAY['Royal','Gold','Crystal','Riyadh','Elite','Amber'];
  flv_ar text[] := ARRAY['نعناع','تفاح','عنب','توت','ليمون','برتقال','مانجو','شمام','فراولة','كراميل','قهوة','بطيخ'];
  flv_en text[] := ARRAY['Mint','Apple','Grape','Berry','Lemon','Orange','Mango','Melon','Strawberry','Caramel','Coffee','Watermelon'];
  flv_profile text[] := ARRAY['mint','fruit','fruit','fruit','citrus','citrus','fruit','fruit','fruit','dessert','dessert','fruit'];
  k int; s int; f int; f2 int; f3 int; n int;
  flavored boolean;
  price numeric;
  name_ar text; name_en text;
  opts jsonb;
  nic text[];
  prof text;
  url text;
  photo bigint;
BEGIN
  FOR n IN 1..520 LOOP
    k := ((n - 1) % 7) + 1;
    s := (n % 6) + 1;
    f := ((n * 7) % 12) + 1;
    f2 := (f % 12) + 1;
    f3 := ((f + 1) % 12) + 1;
    flavored := k IN (1, 2, 3);
    price := cat_base[k] + ((n * 17) % 60);

    IF flavored THEN
      name_ar := cat_ar[k] || ' ' || series_ar[s] || ' ' || flv_ar[f] || ' ' || lpad(n::text, 3, '0');
      name_en := cat_en[k] || ' ' || series_en[s] || ' ' || flv_en[f] || ' ' || lpad(n::text, 3, '0');
      opts := jsonb_build_array(
        jsonb_build_object('ar', flv_ar[f], 'en', flv_en[f]),
        jsonb_build_object('ar', flv_ar[f2], 'en', flv_en[f2]),
        jsonb_build_object('ar', flv_ar[f3], 'en', flv_en[f3]));
      prof := flv_profile[f];
    ELSE
      name_ar := cat_ar[k] || ' ' || series_ar[s] || ' ' || lpad(n::text, 3, '0');
      name_en := cat_en[k] || ' ' || series_en[s] || ' ' || lpad(n::text, 3, '0');
      opts := '[]'::jsonb;
      prof := 'none';
    END IF;

    IF k = 1 OR k = 2 OR k = 3 THEN
      nic := ARRAY['0mg','3mg','20mg','50mg'];
    ELSIF k = 5 THEN
      nic := ARRAY['0mg','20mg','50mg'];
    ELSE
      nic := '{}'::text[];
    END IF;

    photo := photo_ids[((k - 1) * 3) + (n % 3) + 1];
    url := 'https://images.pexels.com/photos/' || photo || '/pexels-photo-' || photo || '.jpeg?auto=compress&cs=tinysrgb&h=650&w=940';

    INSERT INTO products (
      id, category_id, name_ar, name_en, description_ar, description_en,
      price, compare_at_price, stock, image_url, flavor_profile, flavor_options, nicotine_levels
    ) VALUES (
      'KW-' || lpad(n::text, 4, '0'), cat_ids[k], name_ar, name_en, cat_desc_ar[k], cat_desc_en[k],
      price, CASE WHEN n % 5 = 0 THEN round(price * 1.2) END, (n * 37) % 60, url, prof, opts, nic
    ) ON CONFLICT (id) DO NOTHING;
  END LOOP;
END $$;
