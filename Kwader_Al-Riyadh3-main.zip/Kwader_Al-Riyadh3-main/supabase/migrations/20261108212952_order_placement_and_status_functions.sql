/*
# Order placement and status functions with inventory control

1. New Functions
- `place_order(p_items, p_coupon)`: validates every cart line against the live catalog, recalculates prices on the server, applies the coupon and shipping, deducts stock, and saves the order. Returns the saved order.
- `set_order_status(p_order_id, p_status)`: changes an order's status. Cancelling restores the stock for its items. Reopening a cancelled order deducts the stock again.

2. Inventory Rules
- Stock is deducted only when an order is placed (customer confirms via WhatsApp) or when an admin reopens a cancelled order.
- Adding to cart never changes stock.

3. Security
- Both functions run with the owner's rights and pin the search path to public, so the browser cannot bypass the rules.
- Execute is revoked from the public role and granted only to anon and authenticated, because the app has no sign-in.
- Prices and totals are always taken from the database, never from the browser.

4. Notes
- Error messages are coded (OUT_OF_STOCK, INVALID_COUPON, EMPTY_CART, INVALID_QTY, PRODUCT_NOT_FOUND, INVALID_STATUS, ORDER_NOT_FOUND) so the app can show a clear message.
*/

CREATE OR REPLACE FUNCTION place_order(p_items jsonb, p_coupon text DEFAULT NULL)
RETURNS orders
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  item jsonb;
  prod products%ROWTYPE;
  qty int;
  subtotal numeric := 0;
  discount numeric := 0;
  shipping numeric := 0;
  pct int := 0;
  threshold numeric;
  fee numeric;
  coupon text;
  line_items jsonb := '[]'::jsonb;
  new_order orders%ROWTYPE;
BEGIN
  IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array' OR jsonb_array_length(p_items) = 0 THEN
    RAISE EXCEPTION 'EMPTY_CART';
  END IF;

  FOR item IN SELECT * FROM jsonb_array_elements(p_items) LOOP
    BEGIN
      qty := (item->>'qty')::int;
    EXCEPTION WHEN others THEN
      RAISE EXCEPTION 'INVALID_QTY';
    END;
    IF qty IS NULL OR qty < 1 OR qty > 999 THEN
      RAISE EXCEPTION 'INVALID_QTY';
    END IF;

    SELECT * INTO prod FROM products WHERE id = item->>'product_id' FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'PRODUCT_NOT_FOUND';
    END IF;
    IF prod.stock < qty THEN
      RAISE EXCEPTION 'OUT_OF_STOCK:%', prod.id;
    END IF;

    UPDATE products SET stock = stock - qty WHERE id = prod.id;
    subtotal := subtotal + prod.price * qty;

    line_items := line_items || jsonb_build_array(jsonb_build_object(
      'product_id', prod.id,
      'name_ar', prod.name_ar,
      'name_en', prod.name_en,
      'price', prod.price,
      'qty', qty,
      'flavor', item->>'flavor',
      'nicotine', item->>'nicotine'
    ));
  END LOOP;

  coupon := NULLIF(upper(btrim(coalesce(p_coupon, ''))), '');
  IF coupon IS NOT NULL THEN
    SELECT percent INTO pct FROM promo_codes WHERE code = coupon AND active;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'INVALID_COUPON';
    END IF;
    discount := round(subtotal * pct / 100, 2);
  END IF;

  threshold := coalesce((SELECT value::numeric FROM site_settings WHERE key = 'free_shipping_threshold'), 200);
  fee := coalesce((SELECT value::numeric FROM site_settings WHERE key = 'shipping_fee'), 20);
  IF subtotal - discount < threshold THEN
    shipping := fee;
  END IF;

  INSERT INTO orders (order_number, items, subtotal, discount, shipping, total, coupon_code)
  VALUES (
    'KW-' || upper(substr(md5(gen_random_uuid()::text), 1, 8)),
    line_items,
    subtotal,
    discount,
    shipping,
    subtotal - discount + shipping,
    coupon
  )
  RETURNING * INTO new_order;

  RETURN new_order;
END;
$$;

CREATE OR REPLACE FUNCTION set_order_status(p_order_id uuid, p_status text)
RETURNS orders
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_order orders%ROWTYPE;
  item jsonb;
  qty int;
  prod_stock int;
BEGIN
  IF p_status NOT IN ('new', 'preparing', 'delivered', 'cancelled') THEN
    RAISE EXCEPTION 'INVALID_STATUS';
  END IF;

  SELECT * INTO current_order FROM orders WHERE id = p_order_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'ORDER_NOT_FOUND';
  END IF;

  IF current_order.status <> 'cancelled' AND p_status = 'cancelled' THEN
    FOR item IN SELECT * FROM jsonb_array_elements(current_order.items) LOOP
      UPDATE products
        SET stock = stock + (item->>'qty')::int
        WHERE id = item->>'product_id';
    END LOOP;
  ELSIF current_order.status = 'cancelled' AND p_status <> 'cancelled' THEN
    FOR item IN SELECT * FROM jsonb_array_elements(current_order.items) LOOP
      qty := (item->>'qty')::int;
      SELECT stock INTO prod_stock FROM products WHERE id = item->>'product_id' FOR UPDATE;
      IF NOT FOUND OR prod_stock < qty THEN
        RAISE EXCEPTION 'OUT_OF_STOCK:%', item->>'product_id';
      END IF;
      UPDATE products SET stock = stock - qty WHERE id = item->>'product_id';
    END LOOP;
  END IF;

  UPDATE orders
    SET status = p_status, updated_at = now()
    WHERE id = p_order_id
    RETURNING * INTO current_order;

  RETURN current_order;
END;
$$;

REVOKE EXECUTE ON FUNCTION place_order(jsonb, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION place_order(jsonb, text) TO anon, authenticated;

REVOKE EXECUTE ON FUNCTION set_order_status(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION set_order_status(uuid, text) TO anon, authenticated;
