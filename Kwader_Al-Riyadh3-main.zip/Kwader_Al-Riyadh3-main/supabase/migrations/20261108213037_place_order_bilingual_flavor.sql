/*
# Store selected flavor as a bilingual object on orders

1. Modified Functions
- `place_order`: each order line now keeps the chosen flavor as an object with Arabic and English names, instead of a plain text value. Everything else is unchanged: server-side pricing, coupon checks, shipping, and stock deduction.

2. Security
- Same execute grants as before (anon and authenticated only). Function rebuilt with the same search path pinning.

3. Notes
- Existing orders are not changed.
*/

CREATE OR REPLACE FUNCTION place_order(p_items jsonb, p_coupon text DEFAULT NULL)
RETURNS orders
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  item jsonb;
  prod products%ROWTYPE;
  qty int;
  subtotal numeric := 0;
  discount numeric := 0;
  shipping numeric := 0;
  pct int := 0;
  threshold numeric;
  fee numeric;
  coupon text;
  line_items jsonb := '[]'::jsonb;
  new_order orders%ROWTYPE;
BEGIN
  IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array' OR jsonb_array_length(p_items) = 0 THEN
    RAISE EXCEPTION 'EMPTY_CART';
  END IF;

  FOR item IN SELECT * FROM jsonb_array_elements(p_items) LOOP
    BEGIN
      qty := (item->>'qty')::int;
    EXCEPTION WHEN others THEN
      RAISE EXCEPTION 'INVALID_QTY';
    END;
    IF qty IS NULL OR qty < 1 OR qty > 999 THEN
      RAISE EXCEPTION 'INVALID_QTY';
    END IF;

    SELECT * INTO prod FROM products WHERE id = item->>'product_id' FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'PRODUCT_NOT_FOUND';
    END IF;
    IF prod.stock < qty THEN
      RAISE EXCEPTION 'OUT_OF_STOCK:%', prod.id;
    END IF;

    UPDATE products SET stock = stock - qty WHERE id = prod.id;
    subtotal := subtotal + prod.price * qty;

    line_items := line_items || jsonb_build_array(jsonb_build_object(
      'product_id', prod.id,
      'name_ar', prod.name_ar,
      'name_en', prod.name_en,
      'price', prod.price,
      'qty', qty,
      'flavor', item->'flavor',
      'nicotine', item->>'nicotine'
    ));
  END LOOP;

  coupon := NULLIF(upper(btrim(coalesce(p_coupon, ''))), '');
  IF coupon IS NOT NULL THEN
    SELECT percent INTO pct FROM promo_codes WHERE code = coupon AND active;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'INVALID_COUPON';
    END IF;
    discount := round(subtotal * pct / 100, 2);
  END IF;

  threshold := coalesce((SELECT value::numeric FROM site_settings WHERE key = 'free_shipping_threshold'), 200);
  fee := coalesce((SELECT value::numeric FROM site_settings WHERE key = 'shipping_fee'), 20);
  IF subtotal - discount < threshold THEN
    shipping := fee;
  END IF;

  INSERT INTO orders (order_number, items, subtotal, discount, shipping, total, coupon_code)
  VALUES (
    'KW-' || upper(substr(md5(gen_random_uuid()::text), 1, 8)),
    line_items,
    subtotal,
    discount,
    shipping,
    subtotal - discount + shipping,
    coupon
  )
  RETURNING * INTO new_order;

  RETURN new_order;
END;
$$;
