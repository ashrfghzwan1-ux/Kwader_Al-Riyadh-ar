/** @type {import('tailwindcss').Config} */
const token = (name) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        bg: token('bg'),
        surface: token('surface'),
        'surface-2': token('surface-2'),
        ink: token('ink'),
        muted: token('muted'),
        line: token('line'),
        accent: token('accent'),
        'accent-strong': token('accent-strong'),
        gold: token('gold'),
        'gold-text': token('gold-text'),
        emerald: token('emerald'),
      },
      fontFamily: {
        sans: ['Cairo', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        marquee: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(50%)' },
        },
      },
      boxShadow: {
        gold: '0 18px 40px -18px rgb(var(--gold) / 0.55)',
        lift: '0 24px 60px -28px rgb(0 0 0 / 0.55)',
      },
    },
  },
  plugins: [],
};
